import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;

class AuthenticationRepository {
  final firebase_auth.FirebaseAuth _firebaseAuth;

  AuthenticationRepository({firebase_auth.FirebaseAuth? firebaseAuth})
      : _firebaseAuth = firebaseAuth ?? firebase_auth.FirebaseAuth.instance;

  Stream<firebase_auth.User?> get user => _firebaseAuth.authStateChanges();

  firebase_auth.User? get currentUser => _firebaseAuth.currentUser;

  Future<void> signInWithEmailAndPassword({
    required String email,
    required String password,
  }) async {
    try {
      await _firebaseAuth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
    } catch (e) {
      throw LoginFailure.fromCode(e.toString());
    }
  }

  Future<void> signUpWithEmailAndPassword({
    required String email,
    required String password,
  }) async {
    try {
      await _firebaseAuth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
    } catch (e) {
      throw SignUpFailure.fromCode(e.toString());
    }
  }

  Future<void> signOut() async {
    await _firebaseAuth.signOut();
  }
}

class LoginFailure implements Exception {
  final String message;

  const LoginFailure([this.message = 'An unknown exception occurred.']);

  factory LoginFailure.fromCode(String code) {
    switch (code) {
      case 'invalid-email':
        return const LoginFailure('Email is not valid or badly formatted.');
      case 'user-disabled':
        return const LoginFailure('This user has been disabled. Please contact support.');
      case 'user-not-found':
        return const LoginFailure('Email is not found, please create an account.');
      case 'wrong-password':
        return const LoginFailure('Incorrect password, please try again.');
      default:
        return const LoginFailure();
    }
  }
}

class SignUpFailure implements Exception {
  final String message;

  const SignUpFailure([this.message = 'An unknown exception occurred.']);

  factory SignUpFailure.fromCode(String code) {
    switch (code) {
      case 'invalid-email':
        return const SignUpFailure('Email is not valid or badly formatted.');
      case 'user-disabled':
        return const SignUpFailure('This user has been disabled. Please contact support.');
      case 'email-already-in-use':
        return const SignUpFailure('An account already exists for that email.');
      case 'operation-not-allowed':
        return const SignUpFailure('Operation is not allowed. Please contact support.');
      case 'weak-password':
        return const SignUpFailure('Please enter a stronger password.');
      default:
        return const SignUpFailure();
    }
  }
}