import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:uuid/uuid.dart';
import 'package:path/path.dart' as p;

/// ===================== Models =====================

class UploadedFile {
  final String filename;
  final String url;
  final String thumbnail;
  final int size;

  UploadedFile({
    required this.filename,
    required this.url,
    required this.thumbnail,
    required this.size,
  });

  @override
  String toString() =>
      'UploadedFile(filename: $filename, url: $url, size: $size)';
}

class ScreenItem {
  final String id;
  final String pairingCode;
  final String screenName;
  final String? description;
  final DateTime createdAt;

  ScreenItem({
    required this.id,
    required this.pairingCode,
    required this.screenName,
    this.description,
    required this.createdAt,
  });

  factory ScreenItem.fromJson(Map<String, dynamic> json) {
    return ScreenItem(
      id: json['id'] ?? json['pairingCode'] ?? '',
      pairingCode: json['pairingCode'] ?? '',
      screenName: json['screenName'] ?? '',
      description: json['description'],
      createdAt: DateTime.tryParse(json['createdAt'] ?? '') ?? DateTime.now(),
    );
  }

  @override
  String toString() =>
      'ScreenItem(id: $id, pairingCode: $pairingCode, screenName: $screenName)';
}

/// ===================== Persistent WebSocket Service =====================
class WebSocketS3Service {
  final String url;
  final bool allowSelfSigned;
  final void Function(String msg)? onLog;
  WebSocket? _socket;
  Completer<void>? _connectedCompleter;
  final StreamController<Map<String, dynamic>> _inController =
      StreamController.broadcast();
  Timer? _reconnectTimer;
  bool _connecting = false;
  int _reconnectAttempts = 0;

  WebSocketS3Service(this.url, {this.allowSelfSigned = false, this.onLog});

  /// 🔹 Public stream for consumers
  Stream<Map<String, dynamic>> get messages => _inController.stream;

  // ===================== Logging =====================
  void _log(String message) {
    if (onLog != null) {
      onLog!(message);
    } else {
      print('[WS] $message');
    }
  }

  // ===================== Connection =====================
  Future<void> connect() async {
    if (_socket != null && _socket!.readyState == WebSocket.open) {
      return;
    }
    if (_connecting) {
      return _connectedCompleter?.future ?? Future.value();
    }

    _connecting = true;
    _connectedCompleter = Completer<void>();

    try {
      if (url.startsWith('wss://') && allowSelfSigned) {
        final client = HttpClient()
          ..badCertificateCallback =
              (X509Certificate cert, String host, int port) => true;
        _socket = await WebSocket.connect(url, customClient: client);
      } else {
        _socket = await WebSocket.connect(url);
      }

      _socket!.pingInterval = const Duration(seconds: 20);
      _socket!.listen(
        _onRawMessage,
        onError: _onError,
        onDone: _onDone,
        cancelOnError: true,
      );

      _log('✅ Connected to $url');
      _reconnectAttempts = 0;

      // ✅ mark connection ready
      _connectedCompleter?.complete();
    } catch (e) {
      _log('❌ Connect failed: $e — retrying...');
      _scheduleReconnect();
      _connectedCompleter?.completeError(e);
    } finally {
      _connecting = false;
    }

    return _connectedCompleter?.future ?? Future.value();
  }

  void _onRawMessage(dynamic raw) {
    try {
      final data = jsonDecode(raw as String) as Map<String, dynamic>;
      _log('<- $data');
      if (!_inController.isClosed) _inController.add(data);
    } catch (e) {
      _log('Failed decode message: $e raw=$raw');
    }
  }

  void _onError(Object err) {
    _log('Socket error: $err');
    _cleanupSocket();
    _scheduleReconnect();
  }

  void _onDone() {
    _log('Socket closed by server');
    _cleanupSocket();
    _scheduleReconnect();
  }

  void _cleanupSocket() {
    try {
      _socket?.close();
    } catch (_) {}
    _socket = null;
  }

  void _scheduleReconnect({Duration? initialDelay}) {
    final delay =
        initialDelay ?? Duration(seconds: 2 * (_reconnectAttempts + 1));
    _reconnectAttempts++;
    if (_reconnectTimer != null && _reconnectTimer!.isActive) return;
    _reconnectTimer = Timer(delay, connect);
  }

  Future<void> close() async {
    _reconnectTimer?.cancel();
    await _socket?.close();
    await _inController.close();
  }

  Future<void> uploadStopsWithAudio({
    required String pairingCode,
    required List<Map<String, dynamic>> stops,
  }) async {
    for (var stop in stops) {
      String audioBase64 = '';
      String audioName = '';
      if (stop['stop_audio'] != null && stop['stop_audio']!.isNotEmpty) {
        final file = File(stop['stop_audio']);
        audioBase64 = base64Encode(await file.readAsBytes());
        audioName = p.basename(file.path);
      }

      final payload = {
        "type": "add_stop",
        "pairingCode": pairingCode,
        "stop": {
          "stopName": stop['stopName'],
          "latitude": stop['latitude'],
          "longitude": stop['longitude'],
          "stop_audio_name": audioName,
          "stop_audio_base64": audioBase64,
        },
      };

      await _send(payload);
    }
  }

  // ===================== Send/Request Helpers =====================

  Future<void> _send(Map<String, dynamic> payload) async {
    await connect(); // ✅ waits for socket ready

    if (_socket == null || _socket!.readyState != WebSocket.open) {
      throw Exception("❌ WebSocket is not connected");
    }

    final s = jsonEncode(payload);
    _log('-> $payload');
    _socket!.add(s);
  }

  Future<T> _waitForResponse<T>({
    required void Function() sendRequest,
    required bool Function(Map<String, dynamic>) matches,
    required T Function(Map<String, dynamic>) buildResult,
    Duration timeout = const Duration(seconds: 5),
  }) {
    final completer = Completer<T>();

    late StreamSubscription sub;
    sub = messages.listen((rawData) {
      try {
        // Decode if rawData is String
        final data = rawData is String
            ? jsonDecode(rawData as String)
            : rawData;

        if (data['type'] == 'error') {
          sub.cancel();
          completer.completeError(
            Exception(data['message'] ?? 'Unknown error'),
          );
          return;
        }

        if (matches(data)) {
          sub.cancel();
          completer.complete(buildResult(data));
        }
      } catch (e) {
        print('Error parsing WS message: $e');
      }
    });

    sendRequest();

    return completer.future.timeout(
      timeout,
      onTimeout: () {
        sub.cancel();
        throw TimeoutException('Request timed out');
      },
    );
  }

  // ===================== Files =====================
  Future<void> uploadFile({
    required String filePath,
    required void Function(double progress) onProgress,
    required void Function(UploadedFile file) onComplete,
    required void Function(Object error) onError,
    int chunkSize = 1024 * 1024,
    Duration timeout = const Duration(seconds: 60),
  }) async {
    final file = File(filePath);
    if (!await file.exists()) {
      onError('File not found: $filePath');
      return;
    }

    final totalBytes = await file.length();
    final uploadId = const Uuid().v4();
    final fileName = p.basename(filePath);

    StreamSubscription? sub;
    final completer = Completer<void>();

    try {
      sub = messages.listen((data) {
        if (data['uploadId'] == uploadId) {
          if (data['type'] == 'upload_progress') {
            final pVal = double.tryParse(data['progress'].toString()) ?? 0;
            onProgress(pVal);
          } else if (data['type'] == 'upload_complete') {
            final uploaded = UploadedFile(
              filename: fileName,
              url: data['fileUrl'] ?? '',
              thumbnail: data['thumbnailUrl'] ?? data['fileUrl'] ?? '',
              size: totalBytes,
            );
            if (!completer.isCompleted) completer.complete();
            onComplete(uploaded);
          } else if (data['type'] == 'error') {
            final msg = data['message'] ?? 'upload error';
            if (!completer.isCompleted) completer.completeError(msg);
            onError(msg);
          }
        }
      });

      await _send({
        "type": "upload_start",
        "uploadId": uploadId,
        "filename": fileName,
        "totalBytes": totalBytes,
      });

      final stream = file.openRead();
      int sent = 0;
      await for (final chunk in stream) {
        for (var i = 0; i < chunk.length; i += chunkSize) {
          final end = (i + chunkSize > chunk.length)
              ? chunk.length
              : i + chunkSize;
          final piece = chunk.sublist(i, end);
          await _send({
            "type": "upload_chunk",
            "uploadId": uploadId,
            "chunk": base64Encode(piece),
          });
          sent += piece.length;
          onProgress((sent / totalBytes) * 100);
        }
      }

      await _send({"type": "upload_end", "uploadId": uploadId});

      await completer.future.timeout(
        timeout,
        onTimeout: () {
          throw Exception('Upload timed out after ${timeout.inSeconds}s');
        },
      );
    } catch (e) {
      onError(e);
      if (!completer.isCompleted) completer.completeError(e);
    } finally {
      await sub?.cancel();
    }
  }

  Future<List<UploadedFile>> fetchUploadedFiles({
    Duration timeout = const Duration(seconds: 5),
  }) {
    final clientReqId = const Uuid().v4();
    return _waitForResponse<List<UploadedFile>>(
      timeout: timeout,
      sendRequest: () =>
          _send({"type": "list_files", "clientReqId": clientReqId}),
      matches: (data) =>
          data['type'] == 'files_list' &&
          (data['clientReqId'] == null || data['clientReqId'] == clientReqId),
      buildResult: (data) {
        final files = (data['files'] as List)
            .map(
              (f) => UploadedFile(
                filename: f['filename'],
                url: f['url'],
                thumbnail: f['thumbnail'] ?? f['url'],
                size: f['size'] ?? 0,
              ),
            )
            .toList();
        return files;
      },
    );
  }

  Future<void> deleteFiles(List<String> filenames) async {
    if (filenames.isEmpty) return;
    await _send({"type": "delete_files", "filenames": filenames});
  }

  // ===================== Screen Management =====================
  Future<ScreenItem> addScreen(
    String screenName, {
    String? description,
    required String pairingCode,
  }) {
    final id = const Uuid().v4();
    return _waitForResponse<ScreenItem>(
      sendRequest: () => _send({
        "type": "register_screen",
        "screenName": screenName,
        "description": description,
        "id": id,
        "pairingCode": pairingCode,
      }),
      matches: (data) =>
          data['type'] == 'screen_added' && data['screen']?['id'] == id,
      buildResult: (data) => ScreenItem.fromJson(data['screen']),
    );
  }

  Future<void> deleteScreen(String screenId) async {
    await _send({"type": "delete_screen", "screenId": screenId});
  }

  Future<List<ScreenItem>> fetchScreens({
    Duration timeout = const Duration(seconds: 5),
  }) {
    final clientReqId = const Uuid().v4();
    return _waitForResponse<List<ScreenItem>>(
      timeout: timeout,
      sendRequest: () =>
          _send({"type": "list_screens", "clientReqId": clientReqId}),
      matches: (data) =>
          data['type'] == 'screens_list' &&
          (data['clientReqId'] == null || data['clientReqId'] == clientReqId),
      buildResult: (data) {
        final screens = (data['screens'] as List)
            .map((s) => ScreenItem.fromJson(s))
            .toList();
        return screens;
      },
    );
  }

  Future<void> assignContentToScreen({
    required String pairingCode,
    required List<String> files,
  }) async {
    _send({
      "type": "assign_content",
      "pairingCode": pairingCode,
      "files": files,
    });
  }

  Future<List<String>> fetchScreenContents({required String pairingCode}) {
    return _waitForResponse<List<String>>(
      sendRequest: () {
        _send({"type": "fetch_screen_contents", "pairingCode": pairingCode});
      },
      matches: (msg) => msg['type'] == 'screen_contents',
      buildResult: (msg) => List<String>.from(msg['files']),
    );
  }

  Future<void> deleteScreenContent({
    required String pairingCode,
    required String filename,
  }) async {
    _send({
      "type": "delete_screen_content",
      "pairingCode": pairingCode,
      "filename": filename,
    });
  }

  Future<void> reorderScreenContents({
    required String pairingCode,
    required List<String> files,
  }) async {
    _send({
      "type": "reorder_screen_contents",
      "pairingCode": pairingCode,
      "files": files,
    });
  }

  // ===================== Stream Listener API =====================
  /// Consumers can listen like:
  /// `service.onMessage((msg) => print(msg));`
  void onMessage(void Function(Map<String, dynamic>) handler) {
    messages.listen(handler);
  }
}

/// ===================== Models =====================
class Stop {
  final String id;
  final String stopName;
  final double latitude;
  final double longitude;
  final String audioFile;
  final DateTime createdAt;
  final bool? isAssigned;

  Stop({
    required this.id,
    required this.stopName,
    required this.latitude,
    required this.longitude,
    required this.audioFile,
    required this.createdAt,
    this.isAssigned,
  });

  factory Stop.fromJson(Map<String, dynamic> json) {
    return Stop(
      id: json['id'] ?? '', // backend always gives uuid, fallback to empty
      stopName: json['stopName'] ?? json['name'] ?? '',
      latitude: (json['latitude'] as num?)?.toDouble() ?? 0.0,
      longitude: (json['longitude'] as num?)?.toDouble() ?? 0.0,
      audioFile: json['audioFile'] ?? '',
      createdAt: json['createdAt'] != null
          ? DateTime.tryParse(json['createdAt']) ?? DateTime.now()
          : DateTime.now(),
      isAssigned: json['isAssigned'] as bool?,
    );
  }

  Map<String, dynamic> toJson() => {
    "id": id,
    "stopName": stopName,
    "audioFile": audioFile,
    "latitude": latitude,
    "longitude": longitude,
    "createdAt": createdAt.toIso8601String(),
    "isAssigned": isAssigned,
  };

  /// ✅ Handy for Bloc updates
  Stop copyWith({
    String? id,
    String? stopName,
    double? latitude,
    double? longitude,
    String? audioFile,
    DateTime? createdAt,
    bool? isAssigned,
  }) {
    return Stop(
      id: id ?? this.id,
      stopName: stopName ?? this.stopName,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      audioFile: audioFile ?? this.audioFile,
      createdAt: createdAt ?? this.createdAt,
      isAssigned: isAssigned ?? this.isAssigned,
    );
  }

  List<Object?> get props => [
    id,
    stopName,
    latitude,
    longitude,
    audioFile,
    createdAt,
    isAssigned,
  ];

  @override
  String toString() {
    return 'Stop(id: $id, stopName: $stopName, lat: $latitude, lng: $longitude, audioFile: $audioFile, createdAt: $createdAt, isAssigned: $isAssigned)';
  }
}

/// ===================== Stops API =====================
extension StopsApi on WebSocketS3Service {
  /// Fetch all stops
  Future<List<Stop>> fetchStops({
    Duration timeout = const Duration(seconds: 5),
  }) {
    final clientReqId = const Uuid().v4();
    return _waitForResponse<List<Stop>>(
      timeout: timeout,
      sendRequest: () =>
          _send({"type": "list_stops", "clientReqId": clientReqId}),
      matches: (data) =>
          data['type'] == 'stops_list' &&
          (data['clientReqId'] == null || data['clientReqId'] == clientReqId),
      buildResult: (data) {
        return (data['stops'] as List).map((s) => Stop.fromJson(s)).toList();
      },
    );
  }

  /// Add a new stop
  Future<List<Stop>> addStopToScreen({
    required String pairingCode,
    required String stopName,
    required double latitude,
    required double longitude,
    String? audioFile,
  }) {
    final clientReqId = const Uuid().v4();
    return _waitForResponse<List<Stop>>(
      timeout: const Duration(seconds: 5),
      sendRequest: () => _send({
        "type": "add_stop",
        "clientReqId": clientReqId,
        "pairingCode": pairingCode,
        "stopName": stopName,
        "latitude": latitude,
        "longitude": longitude,
        "audioFile": audioFile,
      }),
      matches: (data) =>
          data['type'] == 'stop_added_and_assigned' &&
          data['pairingCode'] == pairingCode,
      buildResult: (data) {
        final stopData = data['stop'];
        return [Stop.fromJson(stopData)];
      },
    );
  }

  Future<List<Stop>> addStopsBatchToScreen({
    required String pairingCode,
    required List<Map<String, dynamic>> stops,
  }) {
    final clientReqId = const Uuid().v4();
    return _waitForResponse<List<Stop>>(
      timeout: const Duration(seconds: 10),
      sendRequest: () => _send({
        "type": "add_stops_batch",
        "clientReqId": clientReqId,
        "pairingCode": pairingCode,
        "stops": stops,
      }),
      matches: (data) =>
          data['type'] == 'stops_batch_added' &&
          data['pairingCode'] == pairingCode,
      buildResult: (data) {
        final stopList = data['stops'] as List;
        return stopList.map((s) => Stop.fromJson(s)).toList();
      },
    );
  }

  void onStopAdded(void Function(Stop stop) callback) {
    onMessage((msg) {
      if (msg['type'] == 'stop_added' ||
          msg['type'] == 'stop_added_and_assigned') {
        callback(Stop.fromJson(msg['stop']));
      }
    });
  }

  void onStopsAssigned(
    void Function(String pairingCode, List<Stop> stops) callback,
  ) {
    onMessage((msg) {
      if (msg['type'] == 'stops_assigned') {
        final stops = (msg['stops'] as List)
            .map((s) => Stop.fromJson(s))
            .toList();
        callback(msg['pairingCode'], stops);
      }
    });
  }

  /// Update an existing stop
  Future<Stop> updateStop({
    required String id,
    String? stopName,
    double? latitude,
    double? longitude,
    String? audioFile,
  }) {
    final clientReqId = const Uuid().v4();
    return _waitForResponse<Stop>(
      sendRequest: () => _send({
        "type": "update_stop",
        "clientReqId": clientReqId,
        "id": id,
        "stopName": stopName,
        "latitude": latitude,
        "longitude": longitude,
        "audioFile": audioFile,
      }),
      matches: (data) =>
          data['type'] == 'stop_updated' && data['stop']?['id'] == id,
      buildResult: (data) => Stop.fromJson(data['stop']),
    );
  }

  /// Delete a stop
  Future<void> deleteStop(String id) async {
    await _send({"type": "delete_stop", "id": id});
  }

  /// ===================== Screen–Stops Assignment =====================
  /// Assign multiple stops to a screen (append, no duplicates)
  Future<List<Stop>> assignStopsToScreen({
    required String pairingCode,
    required List<String> stopIds,
    Duration timeout = const Duration(seconds: 5),
  }) {
    final clientReqId = const Uuid().v4();
    return _waitForResponse<List<Stop>>(
      timeout: timeout,
      sendRequest: () => _send({
        "type": "assign_stops", // ✅ matches backend
        "clientReqId": clientReqId,
        "pairingCode": pairingCode,
        "stopIds": stopIds,
      }),
      matches: (data) =>
          (data['type'] == 'stops_assigned' ||
              data['type'] == 'stops_assigned_confirm') &&
          data['pairingCode'] == pairingCode,
      buildResult: (data) {
        return (data['stops'] as List).map((s) => Stop.fromJson(s)).toList();
      },
    );
  }

  /// Unassign one or more stops from a screen
  Future<List<Stop>> unassignStopsFromScreen({
    required String pairingCode,
    required List<String> stopIds,
    Duration timeout = const Duration(seconds: 5),
  }) {
    final clientReqId = const Uuid().v4();
    return _waitForResponse<List<Stop>>(
      timeout: timeout,
      sendRequest: () => _send({
        "type": "unassign_stops", // ✅ matches backend
        "clientReqId": clientReqId,
        "pairingCode": pairingCode,
        "stopIds": stopIds,
      }),
      matches: (data) =>
          (data['type'] == 'stops_unassigned' ||
              data['type'] == 'stops_unassigned_confirm') &&
          data['pairingCode'] == pairingCode,
      buildResult: (data) {
        return (data['stops'] as List).map((s) => Stop.fromJson(s)).toList();
      },
    );
  }

  /// Add multiple stops manually to a screen
  Future<List<Stop>> addStopsManually({
    required String pairingCode,
    required List<Map<String, dynamic>> stops,
    Duration timeout = const Duration(seconds: 5),
  }) {
    final clientReqId = const Uuid().v4();
    return _waitForResponse<List<Stop>>(
      timeout: timeout,
      sendRequest: () => _send({
        "type": "add_stops_manual",
        "clientReqId": clientReqId,
        "pairingCode": pairingCode,
        "stops": stops,
      }),
      matches: (data) =>
          (data['type'] == 'stops_added_manual' ||
              data['type'] == 'stops_added_manual_confirm') &&
          data['pairingCode'] == pairingCode,
      buildResult: (data) {
        return (data['stops'] as List).map((s) => Stop.fromJson(s)).toList();
      },
    );
  }

  Future<List<Stop>> fetchStopsForScreen(String pairingCode) async {
    final allStops = await fetchStops();
    return fetchScreenStops(
      pairingCode: pairingCode,
      allStops: allStops,
    ).then((list) => list.whereType<Stop>().toList());
  }

  /// Fetch stops for ALL screens, then filter by pairingCode
  Future<List<Stop?>> fetchScreenStops({
    required String pairingCode,
    List<Stop>? allStops, // pass all stops here
    Duration timeout = const Duration(seconds: 5),
  }) {
    final clientReqId = const Uuid().v4();

    return _waitForResponse<List<Stop?>>(
      timeout: timeout,
      sendRequest: () =>
          _send({"type": "list_screen_stops", "clientReqId": clientReqId}),
      matches: (rawData) {
        final data = rawData is String
            ? jsonDecode(rawData as String)
            : rawData;
        return data['type'] == 'screen_stops_list';
      },
      buildResult: (rawData) {
        final data = rawData is String
            ? jsonDecode(rawData as String)
            : rawData;

        final screens = (data['screens'] as List);
        final screen = screens.firstWhere(
          (s) => s['pairingCode'] == pairingCode,
          orElse: () => {"stops": []},
        );

        final stopIds = List<String>.from(screen['stops'] ?? []);

        // Merge with full stop objects
        final mergedStops = stopIds.map((id) {
          final stop = allStops?.firstWhere(
            (s) => s.id == id,
            orElse: () => Stop(
              id: id,
              stopName: '',
              latitude: 0,
              longitude: 0,
              audioFile: '',
              createdAt: DateTime.now(),
              isAssigned: true,
            ),
          );
          return stop?.copyWith(isAssigned: true);
        }).toList();

        return mergedStops;
      },
    );
  }

  void dispose() {
    _socket?.close();
    _inController.close();
  }
}
