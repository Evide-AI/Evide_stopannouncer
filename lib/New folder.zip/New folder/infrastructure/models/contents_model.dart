import 'dart:typed_data';

class ContentModel {
  final String fileUrl;
  final Uint8List thumbnail;
  final Map<String, dynamic> metadata;

  ContentModel({
    required this.fileUrl,
    required this.thumbnail,
    required this.metadata,
  });
}
