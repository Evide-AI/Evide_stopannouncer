import 'package:cloud_firestore/cloud_firestore.dart';
// Remove this import: import 'dart:ffi'; 

class ScreenModel {
  final String id;
  final int uniqueCode; // Changed from Int to int
  final String screenName;
  final String? description;
  final DateTime lastSeen;
  final bool isOnline;

  ScreenModel({
    required this.id,
    required this.uniqueCode,
    required this.screenName,
    this.description,
    required this.lastSeen,
    required this.isOnline,
  });

  // Enhanced factory constructor with better error handling
  factory ScreenModel.fromFirestore(Map<String, dynamic> data, String documentId) {
    try {
      // Helper function to safely convert to int
      int safeIntConversion(dynamic value, String fieldName) {
        if (value == null) {
          throw FormatException('$fieldName is null');
        }
        if (value is int) return value;
        if (value is double) return value.toInt();
        if (value is String) {
          final parsed = int.tryParse(value);
          if (parsed != null) return parsed;
          throw FormatException('Could not parse $fieldName as int: $value');
        }
        throw FormatException('Unexpected type for $fieldName: ${value.runtimeType}');
      }

      // Helper function to safely convert values to String
      String safeStringConversion(dynamic value, String fieldName) {
        if (value == null) return '';
        if (value is String) return value;
        if (value is int) return value.toString();
        if (value is double) return value.toString();
        if (value is bool) return value.toString();
        
        print('Warning: Unexpected type for $fieldName: ${value.runtimeType}');
        return value.toString();
      }

      // Helper function to safely convert to DateTime
      DateTime safeDateTimeConversion(dynamic value, String fieldName) {
        if (value == null) {
          print('Warning: $fieldName is null, using current time');
          return DateTime.now();
        }
        if (value is Timestamp) return value.toDate();
        if (value is DateTime) return value;
        if (value is String) {
          try {
            return DateTime.parse(value);
          } catch (e) {
            print('Warning: Could not parse $fieldName as DateTime: $value');
            return DateTime.now();
          }
        }
        if (value is int) {
          // Assume it's milliseconds since epoch
          try {
            return DateTime.fromMillisecondsSinceEpoch(value);
          } catch (e) {
            print('Warning: Could not convert $fieldName from int to DateTime: $value');
            return DateTime.now();
          }
        }
        
        print('Warning: Unexpected type for $fieldName: ${value.runtimeType}, using current time');
        return DateTime.now();
      }

      // Helper function to safely convert to bool
      bool safeBoolConversion(dynamic value, String fieldName) {
        if (value == null) return false;
        if (value is bool) return value;
        if (value is String) {
          return value.toLowerCase() == 'true' || value == '1';
        }
        if (value is int) return value != 0;
        if (value is double) return value != 0.0;
        
        print('Warning: Unexpected type for $fieldName: ${value.runtimeType}');
        return false;
      }

      // Extract and convert fields safely
      final uniqueCode = safeIntConversion(data['uniquecode'], 'uniquecode');
      final screenName = safeStringConversion(data['screenname'], 'screenname');
      final description = data['description'] != null 
          ? safeStringConversion(data['description'], 'description') 
          : null;
      final lastSeen = safeDateTimeConversion(data['lastseen'], 'lastseen');
      final isOnline = safeBoolConversion(data['isonline'], 'isonline');

      // Validate required fields
      if (screenName.isEmpty) {
        throw FormatException('screenname is required but was empty or null');
      }

      return ScreenModel(
        id: documentId,
        uniqueCode: uniqueCode,
        screenName: screenName,
        description: description?.isEmpty == true ? null : description,
        lastSeen: lastSeen,
        isOnline: isOnline,
      );
    } catch (e) {
      print('Error creating ScreenModel from data: $data');
      print('Error details: $e');
      rethrow;
    }
  }

  // Convert to Firestore format
  Map<String, dynamic> toFirestore() {
    return {
      'uniquecode': uniqueCode,
      'screenname': screenName,
      if (description != null) 'description': description,
      'lastseen': Timestamp.fromDate(lastSeen),
      'isonline': isOnline,
    };
  }

  // Helper method to get human-readable last seen text
  String getLastSeenText() {
    final now = DateTime.now();
    final difference = now.difference(lastSeen);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays}d ago';
    } else {
      return '${lastSeen.day}/${lastSeen.month}/${lastSeen.year}';
    }
  }

  // Create a copy with updated fields
  ScreenModel copyWith({
    String? id,
    int? uniqueCode, // Changed from String? to int?
    String? screenName,
    String? description,
    DateTime? lastSeen,
    bool? isOnline,
  }) {
    return ScreenModel(
      id: id ?? this.id,
      uniqueCode: uniqueCode ?? this.uniqueCode,
      screenName: screenName ?? this.screenName,
      description: description ?? this.description,
      lastSeen: lastSeen ?? this.lastSeen,
      isOnline: isOnline ?? this.isOnline,
    );
  }

  @override
  String toString() {
    return 'ScreenModel(id: $id, uniqueCode: $uniqueCode, screenName: $screenName, description: $description, lastSeen: $lastSeen, isOnline: $isOnline)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is ScreenModel &&
        other.id == id &&
        other.uniqueCode == uniqueCode &&
        other.screenName == screenName &&
        other.description == description &&
        other.lastSeen == lastSeen &&
        other.isOnline == isOnline;
  }

  @override
  int get hashCode {
    return id.hashCode ^
        uniqueCode.hashCode ^
        screenName.hashCode ^
        description.hashCode ^
        lastSeen.hashCode ^
        isOnline.hashCode;
  }
}