import 'package:flutter/material.dart';

const backgroundColor = Colors.white;
const texColor = Colors.black;