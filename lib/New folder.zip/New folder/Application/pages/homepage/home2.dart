import 'package:evide_dashboard/Application/pages/AddScreens/Screens.dart';
import 'package:evide_dashboard/Application/pages/Contents/contents.dart';
import 'package:evide_dashboard/Application/pages/StopAssign/manual_stop_add.dart';
import 'package:evide_dashboard/Application/pages/Stops/StopScreen.dart';
import 'package:flutter/material.dart';
import 'package:responsive_navigation_bar/responsive_navigation_bar.dart';

class Homescreen extends StatefulWidget {
  const Homescreen({super.key});

  @override
  State<Homescreen> createState() => _HomescreenState();
}

class _HomescreenState extends State<Homescreen> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    const AddscreenWrapper(),
    const ContentsWrapper(),
    // const StopScreenwrapper(),
    const ManualStopWrapper(),
    // const Center(child: Text('BYE')),
  ];

  void changeTab(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      body: _pages[_selectedIndex],
      bottomNavigationBar: ResponsiveNavigationBar(
        selectedIndex: _selectedIndex,
        onTabChange: changeTab,
        // showActiveButtonText: false,
        textStyle: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
        ),
        navigationBarButtons: const <NavigationBarButton>[
          NavigationBarButton(
            text: 'Screens',
            icon: Icons.people,
            backgroundGradient: LinearGradient(
              colors: [Colors.yellow, Colors.green, Colors.blue],
            ),
          ),
          NavigationBarButton(
            text: 'Contents',
            icon: Icons.star,
            backgroundGradient: LinearGradient(
              colors: [Colors.cyan, Colors.teal],
            ),
          ),
          NavigationBarButton(
            text: 'Routes',
            icon: Icons.settings,
            backgroundGradient: LinearGradient(
              colors: [Colors.green, Colors.yellow],
            ),
          ),
          // NavigationBarButton(
          //   text: 'Stops',
          //   icon: Icons.settings,
          //   backgroundGradient: LinearGradient(
          //     colors: [Colors.green, Colors.yellow],
          //   ),
          // ),
          // NavigationBarButton(
          //   text: 'Report',
          //   icon: Icons.settings,
          //   backgroundGradient: LinearGradient(
          //     colors: [Colors.green, Colors.yellow],
          //   ),
          // ),
        ],
      ),
    );
  }
}
