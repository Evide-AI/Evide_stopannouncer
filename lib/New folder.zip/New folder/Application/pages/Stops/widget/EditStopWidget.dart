import 'package:evide_dashboard/Domain/services/websocket_services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:evide_dashboard/Application/pages/Stops/bloc/stops_bloc.dart';

class EditStopWrapper extends StatelessWidget {
  final dynamic stop;
  const EditStopWrapper({super.key, this.stop});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          StopsBloc(WebSocketS3Service('ws://166.0.244.214:8081')),
      child: EditStopScreen(stop: stop),
    );
  }
}

class EditStopScreen extends StatefulWidget {
  final dynamic
  stop; // Replace `dynamic` with your Stop model type if available

  const EditStopScreen({super.key, required this.stop});

  @override
  State<EditStopScreen> createState() => _EditStopScreenState();
}

class _EditStopScreenState extends State<EditStopScreen> {
  late TextEditingController _nameController;
  late TextEditingController _latController;
  late TextEditingController _lngController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.stop.stopName);
    _latController = TextEditingController(
      text: widget.stop.latitude.toString(),
    );
    _lngController = TextEditingController(
      text: widget.stop.longitude.toString(),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _latController.dispose();
    _lngController.dispose();
    super.dispose();
  }

  void _updateStop() {
    final updatedName = _nameController.text.trim();
    final updatedLat = double.tryParse(_latController.text.trim()) ?? 0.0;
    final updatedLng = double.tryParse(_lngController.text.trim()) ?? 0.0;

    if (updatedName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Stop name cannot be empty")),
      );
      return;
    }

    context.read<StopsBloc>().add(
      UpdateStopEvent(
        id: widget.stop.id,
        stopName: updatedName,
        latitude: updatedLat,
        longitude: updatedLng,
        audioFile: widget.stop.audioFile, // keep old audio unless updated
      ),
    );
    context.read<StopsBloc>().add(FetchStopsEvent());
    Navigator.pop(context); // close popup after update
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text("Edit Stop"),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: "Stop Name"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _latController,
              decoration: const InputDecoration(labelText: "Latitude"),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _lngController,
              decoration: const InputDecoration(labelText: "Longitude"),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context), // close dialog
          child: const Text("Cancel"),
        ),
        ElevatedButton(onPressed: _updateStop, child: const Text("Save")),
      ],
    );
  }
}
