// // 1. Remove AddStopWrapper entirely - it's not needed
// // 2. Simplified StopsScreen with consistent bloc passing

// import 'package:evide_dashboard/Application/pages/Stops/bloc/stops_bloc.dart';
// import 'package:evide_dashboard/Application/pages/Stops/widget/EditStopWidget.dart';
// import 'package:evide_dashboard/Domain/services/websocket_services.dart';
// import 'package:file_picker/file_picker.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';

// // Keep your existing StopScreenwrapper - it's correct
// class StopScreenwrapper extends StatelessWidget {
//   const StopScreenwrapper({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return BlocProvider(
//       create: (context) =>
//           StopsBloc(WebSocketS3Service('ws://166.0.244.214:8081'))
//             ..add(FetchStopsEvent()),
//       child: const StopsScreen(),
//     );
//   }
// }

// // Simplified StopsScreen - consistent bloc passing
// class StopsScreen extends StatefulWidget {
//   const StopsScreen({super.key});

//   @override
//   State<StopsScreen> createState() => _StopsScreenState();
// }

// class _StopsScreenState extends State<StopsScreen> {
//   String searchQuery = "";

//   @override
//   void initState() {
//     context.read<StopsBloc>().add(FetchStopsEvent());
//     super.initState();
//   }

//   // Helper method to show Add Stop dialog with proper bloc passing
//   void _showAddStopDialog() {
//     final stopsBloc = context.read<StopsBloc>();
//     showDialog(
//       context: context,
//       barrierDismissible: false,
//       builder: (dialogContext) {
//         return BlocProvider<StopsBloc>.value(
//           value: stopsBloc,
//           child: const AddStopScreen(),
//         );
//       },
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Stops"),
//         actions: [
//           IconButton(
//             icon: const Icon(Icons.refresh),
//             onPressed: () {
//               context.read<StopsBloc>().add(FetchStopsEvent());
//             },
//           ),
//         ],
//       ),
//       body: Column(
//         children: [
//           // Search box
//           Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: TextField(
//               decoration: const InputDecoration(
//                 labelText: "Search stops",
//                 prefixIcon: Icon(Icons.search),
//                 border: OutlineInputBorder(),
//               ),
//               onChanged: (value) {
//                 setState(() {
//                   searchQuery = value.toLowerCase().trim();
//                 });
//               },
//             ),
//           ),

//           // List of stops
//           Expanded(
//             child: BlocBuilder<StopsBloc, StopsState>(
//               builder: (context, state) {
//                 if (state is StopsLoading) {
//                   return const Center(child: CircularProgressIndicator());
//                 } else if (state is StopsLoaded) {
//                   var stops = state.stops;

//                   // Filter by search query
//                   if (searchQuery.isNotEmpty) {
//                     stops = stops
//                         .where(
//                           (s) => s.stopName.toLowerCase().contains(searchQuery),
//                         )
//                         .toList();
//                   }

//                   if (stops.isEmpty && searchQuery.isEmpty) {
//                     // No stops at all - show centered Add button
//                     return Center(
//                       child: Column(
//                         mainAxisSize: MainAxisSize.min,
//                         children: [
//                           IconButton(
//                             icon: const Icon(
//                               Icons.add_circle_outline,
//                               size: 48,
//                               color: Colors.blue,
//                             ),
//                             onPressed: _showAddStopDialog,
//                           ),
//                           const SizedBox(height: 8),
//                           const Text(
//                             "No stops found. Tap + to add a new stop.",
//                           ),
//                         ],
//                       ),
//                     );
//                   }

//                   if (stops.isEmpty && searchQuery.isNotEmpty) {
//                     // No search results - show message with add button
//                     return Center(
//                       child: Column(
//                         mainAxisSize: MainAxisSize.min,
//                         children: [
//                           const Text("No stops match your search."),
//                           const SizedBox(height: 16),
//                           ElevatedButton.icon(
//                             icon: const Icon(Icons.add),
//                             label: const Text("Add New Stop"),
//                             onPressed: _showAddStopDialog,
//                           ),
//                         ],
//                       ),
//                     );
//                   }

//                   // Stops exist - show Add button at top + list
//                   return Column(
//                     children: [
//                       Padding(
//                         padding: const EdgeInsets.all(8.0),
//                         child: ElevatedButton.icon(
//                           icon: const Icon(Icons.add),
//                           label: const Text("Add Stop"),
//                           onPressed:
//                               _showAddStopDialog, // Use consistent method
//                         ),
//                       ),
//                       Expanded(
//                         child: ListView.builder(
//                           itemCount: stops.length,
//                           itemBuilder: (context, index) {
//                             final stop = stops[index];
//                             return Card(
//                               child: ListTile(
//                                 title: Text(stop.stopName),
//                                 subtitle: Text(
//                                   "Lat: ${stop.latitude}, Lng: ${stop.longitude}",
//                                 ),
//                                 trailing: Row(
//                                   mainAxisSize: MainAxisSize.min,
//                                   children: [
//                                     IconButton(
//                                       icon: const Icon(Icons.edit),
//                                       onPressed: () {
//                                         // You'll need to fix EditStopWrapper similarly
//                                         showDialog(
//                                           context: context,
//                                           builder: (_) =>
//                                               EditStopWrapper(stop: stop),
//                                         );
//                                       },
//                                     ),
//                                     IconButton(
//                                       icon: const Icon(Icons.delete),
//                                       onPressed: () {
//                                         context.read<StopsBloc>().add(
//                                           DeleteStopEvent(stop.id),
//                                         );
//                                       },
//                                     ),
//                                   ],
//                                 ),
//                               ),
//                             );
//                           },
//                         ),
//                       ),
//                     ],
//                   );
//                 } else if (state is StopsError) {
//                   return Center(child: Text("Error: ${state.message}"));
//                 }

//                 return const Center(child: Text("Press refresh to load stops"));
//               },
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }

// // Simplified AddStopScreen - remove AddStopWrapper entirely
// class AddStopScreen extends StatefulWidget {
//   const AddStopScreen({super.key});

//   @override
//   State<AddStopScreen> createState() => _AddStopScreenState();
// }

// class _AddStopScreenState extends State<AddStopScreen>
//     with SingleTickerProviderStateMixin {
//   final _formKey = GlobalKey<FormState>();
//   final TextEditingController nameCtrl = TextEditingController();
//   final TextEditingController latCtrl = TextEditingController();
//   final TextEditingController lngCtrl = TextEditingController();

//   String? audioFileName;
//   String? audioFilePath;
//   bool isLoading = false;
//   bool isUploading = false;

//   late AnimationController _animationController;
//   late Animation<double> _fadeAnimation;

//   @override
//   void initState() {
//     super.initState();
//     _animationController = AnimationController(
//       duration: const Duration(milliseconds: 300),
//       vsync: this,
//     );
//     _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
//       CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
//     );
//     _animationController.forward();
//   }

//   @override
//   void dispose() {
//     _animationController.dispose();
//     nameCtrl.dispose();
//     latCtrl.dispose();
//     lngCtrl.dispose();
//     super.dispose();
//   }

//   Future<void> _pickAudioFile() async {
//     setState(() => isUploading = true);

//     try {
//       final result = await FilePicker.platform.pickFiles(
//         type: FileType.audio,
//         allowMultiple: false,
//       );

//       if (result != null && result.files.isNotEmpty) {
//         final file = result.files.first;
//         setState(() {
//           audioFileName = file.name;
//           audioFilePath = file.path;
//         });

//         if (mounted) {
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(
//               content: Row(
//                 children: [
//                   const Icon(Icons.check_circle, color: Colors.white),
//                   const SizedBox(width: 8),
//                   Text('Audio file selected: ${file.name}'),
//                 ],
//               ),
//               backgroundColor: Colors.green,
//               duration: const Duration(seconds: 2),
//             ),
//           );
//         }
//       }
//     } catch (e) {
//       if (mounted) {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(
//             content: Row(
//               children: [
//                 Icon(Icons.error, color: Colors.white),
//                 SizedBox(width: 8),
//                 Text('Failed to select audio file'),
//               ],
//             ),
//             backgroundColor: Colors.red,
//           ),
//         );
//       }
//     } finally {
//       setState(() => isUploading = false);
//     }
//   }

//   Future<void> _saveStop() async {
//     if (!_formKey.currentState!.validate()) return;

//     if (audioFilePath == null) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(
//           content: Row(
//             children: [
//               Icon(Icons.warning, color: Colors.white),
//               SizedBox(width: 8),
//               Text('Please select an audio file'),
//             ],
//           ),
//           backgroundColor: Colors.orange,
//         ),
//       );
//       return;
//     }

//     setState(() => isLoading = true);

//     try {
//       final stopName = nameCtrl.text.trim();
//       final latitude = double.tryParse(latCtrl.text.trim()) ?? 0.0;
//       final longitude = double.tryParse(lngCtrl.text.trim()) ?? 0.0;

//       // Get the bloc from context - it should be available now
//       final stopsBloc = context.read<StopsBloc>();

//       print('Adding stop: $stopName at $latitude, $longitude');

//       // Add the stop
//       stopsBloc.add(
//         AddStopEvent(
//           stopName: stopName,
//           latitude: latitude,
//           longitude: longitude,
//           audioFile: audioFilePath!,
//         ),
//       );

//       // Listen for success/error and close dialog
//       final subscription = stopsBloc.stream.listen((state) {
//         if (!mounted) return;

//         if (state is StopsLoaded) {
//           setState(() => isLoading = false);
//           Navigator.of(context).pop(); // Close dialog

//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(
//               content: Row(
//                 children: [
//                   const Icon(Icons.add_circle, color: Colors.white),
//                   const SizedBox(width: 8),
//                   Text('Stop "$stopName" added successfully!'),
//                 ],
//               ),
//               backgroundColor: Colors.green,
//               duration: const Duration(seconds: 3),
//             ),
//           );
//         } else if (state is StopsError) {
//           setState(() => isLoading = false);
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(
//               content: Row(
//                 children: [
//                   const Icon(Icons.error, color: Colors.white),
//                   const SizedBox(width: 8),
//                   Text('Error: ${state.message}'),
//                 ],
//               ),
//               backgroundColor: Colors.red,
//               duration: const Duration(seconds: 4),
//             ),
//           );
//         }
//       });

//       // Auto-cancel subscription after 10 seconds
//       Future.delayed(const Duration(seconds: 10), () {
//         subscription.cancel();
//         if (mounted && isLoading) {
//           setState(() => isLoading = false);
//           ScaffoldMessenger.of(context).showSnackBar(
//             const SnackBar(
//               content: Row(
//                 children: [
//                   Icon(Icons.warning, color: Colors.white),
//                   SizedBox(width: 8),
//                   Text('Operation timed out. Please try again.'),
//                 ],
//               ),
//               backgroundColor: Colors.orange,
//             ),
//           );
//         }
//       });
//     } catch (e) {
//       print('Error adding stop: $e');
//       if (mounted) {
//         setState(() => isLoading = false);
//         ScaffoldMessenger.of(context).showSnackBar(
//           SnackBar(
//             content: Row(
//               children: [
//                 const Icon(Icons.error, color: Colors.white),
//                 const SizedBox(width: 8),
//                 Text('Failed to add stop: ${e.toString()}'),
//               ],
//             ),
//             backgroundColor: Colors.red,
//             duration: const Duration(seconds: 4),
//           ),
//         );
//       }
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     final theme = Theme.of(context);
//     final colorScheme = theme.colorScheme;

//     return FadeTransition(
//       opacity: _fadeAnimation,
//       child: Dialog(
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
//         elevation: 16,
//         child: Container(
//           constraints: const BoxConstraints(maxWidth: 500, maxHeight: 600),
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               // Header
//               Container(
//                 padding: const EdgeInsets.all(24),
//                 decoration: BoxDecoration(
//                   gradient: LinearGradient(
//                     colors: [
//                       colorScheme.primary,
//                       colorScheme.primary.withOpacity(0.8),
//                     ],
//                     begin: Alignment.topLeft,
//                     end: Alignment.bottomRight,
//                   ),
//                   borderRadius: const BorderRadius.only(
//                     topLeft: Radius.circular(20),
//                     topRight: Radius.circular(20),
//                   ),
//                 ),
//                 child: Row(
//                   children: [
//                     Container(
//                       padding: const EdgeInsets.all(8),
//                       decoration: BoxDecoration(
//                         color: Colors.white.withOpacity(0.2),
//                         borderRadius: BorderRadius.circular(12),
//                       ),
//                       child: const Icon(
//                         Icons.add_location_alt,
//                         color: Colors.white,
//                         size: 24,
//                       ),
//                     ),
//                     const SizedBox(width: 16),
//                     Expanded(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(
//                             'Add New Stop',
//                             style: theme.textTheme.headlineSmall?.copyWith(
//                               color: Colors.white,
//                               fontWeight: FontWeight.bold,
//                             ),
//                           ),
//                           const SizedBox(height: 4),
//                           Text(
//                             'Create a new bus stop location',
//                             style: theme.textTheme.bodyMedium?.copyWith(
//                               color: Colors.white.withOpacity(0.9),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ],
//                 ),
//               ),

//               // Form Content
//               Flexible(
//                 child: Form(
//                   key: _formKey,
//                   child: Padding(
//                     padding: const EdgeInsets.all(24),
//                     child: SingleChildScrollView(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.stretch,
//                         children: [
//                           // Stop Name Field
//                           _buildTextField(
//                             controller: nameCtrl,
//                             label: 'Stop Name',
//                             icon: Icons.location_on,
//                             hint: 'Enter the stop name',
//                             validator: (val) => val == null || val.isEmpty
//                                 ? 'Please enter stop name'
//                                 : null,
//                           ),

//                           const SizedBox(height: 20),

//                           // Location Fields Row
//                           Row(
//                             children: [
//                               Expanded(
//                                 child: _buildTextField(
//                                   controller: latCtrl,
//                                   label: 'Latitude',
//                                   icon: Icons.my_location,
//                                   hint: 'e.g., 11.2588',
//                                   keyboardType:
//                                       const TextInputType.numberWithOptions(
//                                         decimal: true,
//                                         signed: true,
//                                       ),
//                                   inputFormatters: [
//                                     FilteringTextInputFormatter.allow(
//                                       RegExp(r'^-?\d*\.?\d*'),
//                                     ),
//                                   ],
//                                   validator: (val) {
//                                     if (val == null || val.isEmpty) {
//                                       return 'Required';
//                                     }
//                                     final num? lat = double.tryParse(val);
//                                     if (lat == null || lat < -90 || lat > 90) {
//                                       return 'Invalid latitude';
//                                     }
//                                     return null;
//                                   },
//                                 ),
//                               ),
//                               const SizedBox(width: 16),
//                               Expanded(
//                                 child: _buildTextField(
//                                   controller: lngCtrl,
//                                   label: 'Longitude',
//                                   icon: Icons.place,
//                                   hint: 'e.g., 75.7804',
//                                   keyboardType:
//                                       const TextInputType.numberWithOptions(
//                                         decimal: true,
//                                         signed: true,
//                                       ),
//                                   inputFormatters: [
//                                     FilteringTextInputFormatter.allow(
//                                       RegExp(r'^-?\d*\.?\d*'),
//                                     ),
//                                   ],
//                                   validator: (val) {
//                                     if (val == null || val.isEmpty) {
//                                       return 'Required';
//                                     }
//                                     final num? lng = double.tryParse(val);
//                                     if (lng == null ||
//                                         lng < -180 ||
//                                         lng > 180) {
//                                       return 'Invalid longitude';
//                                     }
//                                     return null;
//                                   },
//                                 ),
//                               ),
//                             ],
//                           ),

//                           const SizedBox(height: 24),

//                           // Audio File Upload
//                           _buildAudioUploadSection(colorScheme),

//                           const SizedBox(height: 32),

//                           // Action Buttons
//                           Row(
//                             children: [
//                               Expanded(
//                                 child: OutlinedButton.icon(
//                                   onPressed: isLoading
//                                       ? null
//                                       : () => Navigator.of(context).pop(),
//                                   icon: const Icon(Icons.close),
//                                   label: const Text('Cancel'),
//                                   style: OutlinedButton.styleFrom(
//                                     padding: const EdgeInsets.symmetric(
//                                       vertical: 16,
//                                     ),
//                                     side: BorderSide(
//                                       color: colorScheme.outline,
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                               const SizedBox(width: 16),
//                               Expanded(
//                                 child: ElevatedButton.icon(
//                                   onPressed: isLoading ? null : _saveStop,
//                                   icon: isLoading
//                                       ? const SizedBox(
//                                           width: 16,
//                                           height: 16,
//                                           child: CircularProgressIndicator(
//                                             strokeWidth: 2,
//                                             color: Colors.white,
//                                           ),
//                                         )
//                                       : const Icon(Icons.save),
//                                   label: Text(
//                                     isLoading ? 'Adding...' : 'Add Stop',
//                                   ),
//                                   style: ElevatedButton.styleFrom(
//                                     padding: const EdgeInsets.symmetric(
//                                       vertical: 16,
//                                     ),
//                                     backgroundColor: colorScheme.primary,
//                                     foregroundColor: Colors.white,
//                                   ),
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   Widget _buildTextField({
//     required TextEditingController controller,
//     required String label,
//     required IconData icon,
//     String? hint,
//     TextInputType? keyboardType,
//     List<TextInputFormatter>? inputFormatters,
//     String? Function(String?)? validator,
//   }) {
//     return TextFormField(
//       controller: controller,
//       keyboardType: keyboardType,
//       inputFormatters: inputFormatters,
//       validator: validator,
//       decoration: InputDecoration(
//         labelText: label,
//         hintText: hint,
//         prefixIcon: Icon(icon, size: 20),
//         border: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(12),
//           borderSide: BorderSide(color: Colors.grey.shade300),
//         ),
//         enabledBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(12),
//           borderSide: BorderSide(color: Colors.grey.shade300),
//         ),
//         focusedBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(12),
//           borderSide: BorderSide(
//             color: Theme.of(context).colorScheme.primary,
//             width: 2,
//           ),
//         ),
//         errorBorder: OutlineInputBorder(
//           borderRadius: BorderRadius.circular(12),
//           borderSide: const BorderSide(color: Colors.red, width: 2),
//         ),
//         filled: true,
//         fillColor: Colors.grey.shade50,
//         contentPadding: const EdgeInsets.symmetric(
//           horizontal: 16,
//           vertical: 16,
//         ),
//       ),
//     );
//   }

//   Widget _buildAudioUploadSection(ColorScheme colorScheme) {
//     return Container(
//       padding: const EdgeInsets.all(20),
//       decoration: BoxDecoration(
//         border: Border.all(
//           color: audioFileName != null
//               ? colorScheme.primary
//               : Colors.grey.shade300,
//           width: audioFileName != null ? 2 : 1,
//         ),
//         borderRadius: BorderRadius.circular(16),
//         color: audioFileName != null
//             ? colorScheme.primary.withOpacity(0.05)
//             : Colors.grey.shade50,
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.stretch,
//         children: [
//           Row(
//             children: [
//               Container(
//                 padding: const EdgeInsets.all(8),
//                 decoration: BoxDecoration(
//                   color: audioFileName != null
//                       ? colorScheme.primary.withOpacity(0.1)
//                       : Colors.grey.shade200,
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//                 child: Icon(
//                   audioFileName != null ? Icons.audiotrack : Icons.upload_file,
//                   color: audioFileName != null
//                       ? colorScheme.primary
//                       : Colors.grey.shade600,
//                 ),
//               ),
//               const SizedBox(width: 12),
//               Expanded(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text(
//                       audioFileName != null
//                           ? 'Audio File Selected'
//                           : 'Upload Audio File',
//                       style: TextStyle(
//                         fontWeight: FontWeight.w600,
//                         color: audioFileName != null
//                             ? colorScheme.primary
//                             : Colors.grey.shade700,
//                       ),
//                     ),
//                     const SizedBox(height: 2),
//                     Text(
//                       audioFileName ??
//                           'Select an audio file for the stop announcement',
//                       style: TextStyle(
//                         fontSize: 13,
//                         color: Colors.grey.shade600,
//                       ),
//                       maxLines: 2,
//                       overflow: TextOverflow.ellipsis,
//                     ),
//                   ],
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 16),
//           ElevatedButton.icon(
//             onPressed: isUploading ? null : _pickAudioFile,
//             icon: isUploading
//                 ? const SizedBox(
//                     width: 16,
//                     height: 16,
//                     child: CircularProgressIndicator(strokeWidth: 2),
//                   )
//                 : Icon(
//                     audioFileName != null ? Icons.refresh : Icons.folder_open,
//                   ),
//             label: Text(
//               isUploading
//                   ? 'Selecting...'
//                   : audioFileName != null
//                   ? 'Change Audio File'
//                   : 'Browse Files',
//             ),
//             style: ElevatedButton.styleFrom(
//               backgroundColor: audioFileName != null
//                   ? colorScheme.primary
//                   : Colors.grey.shade100,
//               foregroundColor: audioFileName != null
//                   ? Colors.white
//                   : Colors.grey.shade700,
//               padding: const EdgeInsets.symmetric(vertical: 12),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
