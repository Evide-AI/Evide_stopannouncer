part of 'stops_bloc.dart';

abstract class StopsState extends Equatable {
  const StopsState();
  @override
  List<Object?> get props => [];
}

class StopsInitial extends StopsState {}

class StopsLoading extends StopsState {}

class StopsLoaded extends StopsState {
  final List<Stop> stops;
  const StopsLoaded(this.stops);
  @override
  List<Object?> get props => [stops];
}

class StopsError extends StopsState {
  final String message;
  const StopsError(this.message);
  @override
  List<Object?> get props => [message];
}

class ScreenStopsLoaded extends StopsState {
  final List<Stop?> stops;

  const ScreenStopsLoaded(this.stops);

  @override
  List<Object> get props => [stops];
}

class ScreenStopsUpdated extends StopsState {
  final List<Stop?> stops;

  const ScreenStopsUpdated(this.stops);

  @override
  List<Object> get props => [stops];
}
