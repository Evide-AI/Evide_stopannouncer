import 'dart:async';
import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:evide_dashboard/Domain/services/websocket_services.dart';


part 'stops_event.dart';
part 'stops_state.dart';

class StopsBloc extends Bloc<StopsEvent, StopsState> {
  final WebSocketS3Service wsService;
  late final StreamSubscription _wsSub;

  StopsBloc(this.wsService) : super(StopsInitial()) {
    // Listen for real-time WS updates
    _wsSub = wsService.messages.listen((msg) async {
      try {
        if (msg['type'] == 'stop_added' ||
            msg['type'] == 'stop_added_and_assigned' ||
            msg['type'] == 'stops_assigned') {
          final pairingCode = msg['pairingCode'] as String?;
          if (pairingCode != null) {
            final updatedStops = await wsService.fetchScreenStops(
              pairingCode: pairingCode,
            );
            add(_ScreenStopsUpdatedInternal(updatedStops));
          }
        }
      } catch (e) {
        print('WS message handling error: $e');
      }
    });

    // ------------------ Events ------------------

    // Fetch all stops
    on<FetchStopsEvent>((event, emit) async {
      emit(StopsLoading());
      try {
        final stops = await wsService.fetchStops();
        emit(StopsLoaded(stops));
      } on SocketException {
        emit(const StopsError("Network error while fetching stops"));
      } catch (e) {
        emit(StopsError(e.toString()));
      }
    });

    // Add a new stop (single)
    on<AddStopEvent>((event, emit) async {
      emit(StopsLoading());
      try {
        await wsService.addStopToScreen(
          pairingCode: event.pairingCode,
          stopName: event.stopName,
          latitude: event.latitude,
          longitude: event.longitude,
          audioFile: event.audioFile,
        );

        final updatedStops =
            await wsService.fetchScreenStops(pairingCode: event.pairingCode);
        emit(ScreenStopsUpdated(updatedStops));

        // Refresh full stop list
        add(FetchStopsEvent());
      } catch (e) {
        emit(StopsError('Failed to add stop: $e'));
      }
    });

    // Add multiple stops (batch)
    on<AddManualStopsEvent>((event, emit) async {
      emit(StopsLoading());
      try {
        final updatedStops = await wsService.addStopsBatchToScreen(
          pairingCode: event.pairingCode,
          stops: event.stops,
        );
        emit(ScreenStopsUpdated(updatedStops));

        // Refresh full stop list
        add(FetchStopsEvent());
      } catch (e) {
        emit(StopsError('Failed to upload stops batch: $e'));
      }
    });

    // Update an existing stop
    on<UpdateStopEvent>((event, emit) async {
      emit(StopsLoading());
      try {
        await wsService.updateStop(
          id: event.id,
          stopName: event.stopName,
          latitude: event.latitude,
          longitude: event.longitude,
          audioFile: event.audioFile,
        );
        add(FetchStopsEvent());
      } catch (e) {
        emit(StopsError('Failed to update stop: $e'));
      }
    });

    // Delete a stop
    on<DeleteStopEvent>((event, emit) async {
      emit(StopsLoading());
      try {
        await wsService.deleteStop(event.id);
        add(FetchStopsEvent());
      } catch (e) {
        emit(StopsError('Failed to delete stop: $e'));
      }
    });

    // Fetch stops for a specific screen
    on<FetchScreenStopsEvent>((event, emit) async {
      emit(StopsLoading());
      try {
        final stops =
            await wsService.fetchScreenStops(pairingCode: event.pairingCode);
        emit(ScreenStopsLoaded(stops));
      } catch (e) {
        emit(StopsError('Failed to fetch screen stops: $e'));
      }
    });

    // Assign stops to a screen
    on<AssignStopsToScreenEvent>((event, emit) async {
      emit(StopsLoading());
      try {
        final updatedStops = await wsService.assignStopsToScreen(
          pairingCode: event.pairingCode,
          stopIds: event.stopIds,
        );
        emit(ScreenStopsUpdated(updatedStops));
      } catch (e) {
        emit(StopsError('Failed to assign stops: $e'));
      }
    });

    // Unassign stops from a screen
    on<UnassignStopFromScreenEvent>((event, emit) async {
      emit(StopsLoading());
      try {
        final updatedStops = await wsService.unassignStopsFromScreen(
          pairingCode: event.pairingCode,
          stopIds: [event.stopId],
        );
        emit(ScreenStopsUpdated(updatedStops));
      } catch (e) {
        emit(StopsError('Failed to unassign stop: $e'));
      }
    });

    // Internal event for WS updates
    on<_ScreenStopsUpdatedInternal>((event, emit) {
      emit(ScreenStopsUpdated(event.stops));
    });
  }

  @override
  Future<void> close() {
    _wsSub.cancel();
    return super.close();
  }
}

// Internal event for WS updates
class _ScreenStopsUpdatedInternal extends StopsEvent {
  final List<Stop?> stops;
  const _ScreenStopsUpdatedInternal(this.stops);

  @override
  List<Object?> get props => [stops];
}
