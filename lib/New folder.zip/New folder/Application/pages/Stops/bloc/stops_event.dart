part of 'stops_bloc.dart';

abstract class StopsEvent extends Equatable {
  const StopsEvent();
  @override
  List<Object?> get props => [];
}

class AddManualStopsEvent extends StopsEvent {
  final String pairingCode;
  final List<Map<String, dynamic>> stops;
  const AddManualStopsEvent(this.pairingCode, this.stops);


  @override
  List<Object?> get props => [pairingCode, stops];
}

class FetchStopsEvent extends StopsEvent {}

class AddStopEvent extends StopsEvent {
  final String pairingCode;
  final String stopName;
  final double latitude;
  final double longitude;
  final String audioFile;
  const AddStopEvent(this.pairingCode, {
    required this.stopName,
    required this.latitude,
    required this.longitude,
    required this.audioFile,
  });
}

class UpdateStopEvent extends StopsEvent {
  final String id;
  final String stopName;
  final double latitude;
  final double longitude;
  final String audioFile;
  const UpdateStopEvent({
    required this.id,
    required this.stopName,
    required this.latitude,
    required this.longitude,
    required this.audioFile,
  });
}

class DeleteStopEvent extends StopsEvent {
  final String id;
  const DeleteStopEvent(this.id);
}

class FetchScreenStopsEvent extends StopsEvent {
  final String pairingCode;
  const FetchScreenStopsEvent(this.pairingCode);

  @override
  List<Object> get props => [pairingCode];
}

class AssignStopsToScreenEvent extends StopsEvent {
  final String pairingCode;
  final List<String> stopIds;

  const AssignStopsToScreenEvent(this.pairingCode, this.stopIds);

  @override
  List<Object> get props => [pairingCode, stopIds];
}

class UnassignStopFromScreenEvent extends StopsEvent {
  final String pairingCode;
  final String stopId;

  const UnassignStopFromScreenEvent(this.pairingCode, this.stopId);

  @override
  List<Object> get props => [pairingCode, stopId];
}
