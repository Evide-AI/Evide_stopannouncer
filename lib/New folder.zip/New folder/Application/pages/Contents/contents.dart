import 'package:evide_dashboard/Application/pages/Contents/bloc/contents_bloc.dart';
import 'package:evide_dashboard/Application/pages/Contents/uploads.dart';
import 'package:evide_dashboard/Domain/services/websocket_services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';

class ContentsWrapper extends StatelessWidget {
  const ContentsWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          ContentsBloc(WebSocketS3Service('ws://166.0.244.214:8081')),
      child: const Contents(),
    );
  }
}

class Contents extends StatefulWidget {
  const Contents({super.key});

  @override
  State<Contents> createState() => _ContentsState();
}

class _ContentsState extends State<Contents> {
  final Set<int> selectedIndexes = {};

  void toggleSelection(int index) {
    setState(() {
      if (selectedIndexes.contains(index)) {
        selectedIndexes.remove(index);
      } else {
        selectedIndexes.add(index);
      }
    });
  }

  void deleteSelectedFiles() {
    if (selectedIndexes.isEmpty) return;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          title: Row(
            children: [
              Icon(Icons.warning, color: Colors.red.shade600),
              const Gap(10),
              const Text("Confirm Delete"),
            ],
          ),
          content: Text(
            "Are you sure you want to delete ${selectedIndexes.length} selected file(s)? This action cannot be undone.",
            style: const TextStyle(fontSize: 16),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                "Cancel",
                style: TextStyle(color: Colors.grey.shade600),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                final filesToDelete = selectedIndexes
                    .map(
                      (i) =>
                          this.context.read<ContentsBloc>().state
                              is FilesListLoadedState
                          ? (this.context.read<ContentsBloc>().state
                                    as FilesListLoadedState)
                                .files[i]
                          : null,
                    )
                    .whereType<UploadedFile>()
                    .toList();

                if (filesToDelete.isNotEmpty) {
                  this.context.read<ContentsBloc>().add(
                    DeleteFileEvent(filesToDelete),
                  );
                  setState(() {
                    selectedIndexes.clear();
                  });
                }
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade600,
                foregroundColor: Colors.white,
              ),
              child: const Text("Delete"),
            ),
          ],
        );
      },
    );
  }

  void _showUploadDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: BlocProvider.value(
          value: BlocProvider.of<ContentsBloc>(context),
          child: const Uploads(),
        ),
      ),
    );
  }

  @override
  void initState() {
    context.read<ContentsBloc>().add(const FetchFilesEvent());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: Colors.grey.shade800,
        title: selectedIndexes.isNotEmpty
            ? Text("${selectedIndexes.length} Selected")
            : const Text(
                "Contents",
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
        actions: [
          if (selectedIndexes.isNotEmpty)
            IconButton(
              icon: Icon(Icons.delete, color: Colors.red.shade600),
              onPressed: deleteSelectedFiles,
            ),
        ],
      ),
      body: BlocBuilder<ContentsBloc, ContentsState>(
        builder: (context, state) {
          if (state is ContentLoadingState) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(
                      Colors.blue.shade600,
                    ),
                  ),
                  const Gap(16),
                  Text(
                    "Loading contents...",
                    style: TextStyle(color: Colors.grey.shade600, fontSize: 16),
                  ),
                ],
              ),
            );
          }

          if (state is UploadingFilesState) {
            return Container(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.blue.shade200),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.cloud_upload, color: Colors.blue.shade600),
                        const Gap(12),
                        Text(
                          "Uploading ${state.uploads.length} file(s)...",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: Colors.blue.shade700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Gap(16),
                  Expanded(
                    child: ListView.builder(
                      itemCount: state.uploads.length,
                      itemBuilder: (context, index) {
                        final upload = state.uploads[index];
                        return Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.05),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: upload.completed
                                          ? Colors.green.shade100
                                          : upload.error != null
                                          ? Colors.red.shade100
                                          : Colors.blue.shade100,
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Icon(
                                      upload.completed
                                          ? Icons.check_circle
                                          : upload.error != null
                                          ? Icons.error
                                          : Icons.cloud_upload,
                                      color: upload.completed
                                          ? Colors.green.shade600
                                          : upload.error != null
                                          ? Colors.red.shade600
                                          : Colors.blue.shade600,
                                      size: 20,
                                    ),
                                  ),
                                  const Gap(12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          upload.filename,
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        if (upload.error != null)
                                          Text(
                                            "Error: ${upload.error}",
                                            style: TextStyle(
                                              color: Colors.red.shade600,
                                              fontSize: 14,
                                            ),
                                          )
                                        else if (upload.completed)
                                          Text(
                                            "Upload completed",
                                            style: TextStyle(
                                              color: Colors.green.shade600,
                                              fontSize: 14,
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              if (!upload.completed &&
                                  upload.error == null) ...[
                                const Gap(12),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(6),
                                  child: LinearProgressIndicator(
                                    value: upload.progress / 100,
                                    backgroundColor: Colors.grey.shade200,
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      Colors.blue.shade600,
                                    ),
                                    minHeight: 6,
                                  ),
                                ),
                                const Gap(4),
                                Text(
                                  "${upload.progress.toInt()}%",
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey.shade600,
                                  ),
                                ),
                              ],
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          }

          if (state is FilesListLoadedState) {
            final contents = state.files;

            if (contents.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 200,
                      height: 200,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            Colors.blue.shade100,
                            Colors.purple.shade100,
                          ],
                        ),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            blurRadius: 20,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: _showUploadDialog,
                          borderRadius: BorderRadius.circular(20),
                          child: const Center(
                            child: Icon(
                              Icons.cloud_upload_outlined,
                              size: 80,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const Gap(24),
                    Text(
                      "No Content Available",
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey.shade700,
                      ),
                    ),
                    const Gap(8),
                    Text(
                      "Tap the card above to upload your first content",
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey.shade500,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              );
            }

            return Column(
              children: [
                // Action Bar
                Container(
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          selectedIndexes.isEmpty
                              ? "${contents.length} file(s) available"
                              : "${selectedIndexes.length} file(s) selected",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                            color: Colors.grey.shade700,
                          ),
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.blue.shade50,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: IconButton(
                          onPressed: _showUploadDialog,
                          icon: Icon(
                            Icons.cloud_upload_outlined,
                            color: Colors.blue.shade600,
                          ),
                          tooltip: "Upload files",
                        ),
                      ),
                      if (selectedIndexes.isNotEmpty) ...[
                        const Gap(8),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.red.shade50,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: IconButton(
                            onPressed: deleteSelectedFiles,
                            icon: Icon(
                              Icons.delete_outline,
                              color: Colors.red.shade600,
                            ),
                            tooltip: "Delete selected",
                          ),
                        ),
                      ],
                    ],
                  ),
                ),

                // File List
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: contents.length,
                    itemBuilder: (context, index) {
                      final file = contents[index];
                      final isSelected = selectedIndexes.contains(index);
                      print(
                        'teh filenames.......${getCleanFileName(file.filename)}',
                      );

                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border: isSelected
                              ? Border.all(
                                  color: Colors.blue.shade600,
                                  width: 2,
                                )
                              : null,
                          boxShadow: [
                            BoxShadow(
                              color: isSelected
                                  ? Colors.blue.withOpacity(0.1)
                                  : Colors.black.withOpacity(0.05),
                              blurRadius: isSelected ? 15 : 10,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: () => toggleSelection(index),
                            borderRadius: BorderRadius.circular(12),
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Row(
                                children: [
                                  // File Thumbnail/Icon
                                  Container(
                                    width: 60,
                                    height: 60,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: Colors.grey.shade100,
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(10),
                                      child: file.thumbnail != null
                                          ? Image.network(
                                              file.thumbnail!,
                                              width: 60,
                                              height: 60,
                                              fit: BoxFit.cover,
                                              errorBuilder:
                                                  (context, error, stackTrace) {
                                                    return Icon(
                                                      Icons.broken_image,
                                                      size: 30,
                                                      color:
                                                          Colors.grey.shade400,
                                                    );
                                                  },
                                            )
                                          : Icon(
                                              Icons.insert_drive_file,
                                              size: 30,
                                              color: Colors.grey.shade400,
                                            ),
                                    ),
                                  ),
                                  const Gap(16),

                                  // File Info
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          getCleanFileName(file.filename),
                                          style: const TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        const Gap(4),
                                        Text(
                                          "Size: ${_formatFileSize(file.size)}",
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.grey.shade600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  // Selection Indicator
                                  Container(
                                    width: 24,
                                    height: 24,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: isSelected
                                          ? Colors.blue.shade600
                                          : Colors.transparent,
                                      border: Border.all(
                                        color: isSelected
                                            ? Colors.blue.shade600
                                            : Colors.grey.shade400,
                                        width: 2,
                                      ),
                                    ),
                                    child: isSelected
                                        ? const Icon(
                                            Icons.check,
                                            size: 16,
                                            color: Colors.white,
                                          )
                                        : null,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          }

          if (state is ContentErrorState) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.error_outline,
                    size: 80,
                    color: Colors.red.shade300,
                  ),
                  const Gap(16),
                  Text(
                    "Oops! Something went wrong",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey.shade700,
                    ),
                  ),
                  const Gap(8),
                  Text(
                    state.message,
                    style: TextStyle(fontSize: 16, color: Colors.grey.shade500),
                    textAlign: TextAlign.center,
                  ),
                  const Gap(24),
                  ElevatedButton(
                    onPressed: () {
                      context.read<ContentsBloc>().add(const FetchFilesEvent());
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue.shade600,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text("Try Again"),
                  ),
                ],
              ),
            );
          }

          return const SizedBox.shrink();
        },
      ),
      // floatingActionButton: BlocBuilder<ContentsBloc, ContentsState>(
      //   builder: (context, state) {
      //     if (state is FilesListLoadedState &&
      //         state.files.isNotEmpty &&
      //         selectedIndexes.isEmpty) {
      //       return FloatingActionButton.extended(
      //         onPressed: _showUploadDialog,
      //         backgroundColor: Colors.blue.shade600,
      //         foregroundColor: Colors.white,
      //         icon: const Icon(Icons.cloud_upload),
      //         label: const Text("Upload"),
      //         elevation: 4,
      //       );
      //     }
      //     return const SizedBox.shrink();
      //   },
      // ),
    );
  }

  String _formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024)
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }
}

String getCleanFileName(String fullPath) {
  return fullPath.split('-').last;
}
