part of 'contents_bloc.dart';

abstract class ContentsState extends Equatable {
  const ContentsState();

  @override
  List<Object?> get props => [];
}

/// Initial state
class ContentsInitial extends ContentsState {}

/// State while loading content (fetching files)
class ContentLoadingState extends ContentsState {}

/// State while uploading a file with progress
class UploadingFilesState extends ContentsState {
  final List<UploadStatus> uploads;
  UploadingFilesState(this.uploads);
}

class UploadStatus {
  final String filename;
  final double progress; // 0–100
  final bool completed;
  final String? url;
  final String? error;

  UploadStatus({
    required this.filename,
    this.progress = 0,
    this.completed = false,
    this.url,
    this.error,
  });

  UploadStatus copyWith({
    double? progress,
    bool? completed,
    String? url,
    String? error,
  }) {
    return UploadStatus(
      filename: filename,
      progress: progress ?? this.progress,
      completed: completed ?? this.completed,
      url: url ?? this.url,
      error: error ?? this.error,
    );
  }
}

/// State when a file is successfully uploaded
class FilesListLoadedState extends ContentsState {
  final List<UploadedFile> files;

  const FilesListLoadedState(this.files);

  @override
  List<Object?> get props => [files];
}

class FileUploadedState extends ContentsState {
  final UploadedFile file;

  const FileUploadedState(this.file);

  @override
  List<Object?> get props => [file];
}

/// State when an error occurs
class ContentErrorState extends ContentsState {
  final String message;

  const ContentErrorState({required this.message});

  @override
  List<Object?> get props => [message];
}

class ContentsLoadedState extends ContentsState {
  final List<UploadedFile> files;
  const ContentsLoadedState(this.files);

  @override
  List<Object?> get props => [files];
}
