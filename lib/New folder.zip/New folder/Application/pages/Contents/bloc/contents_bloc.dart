import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:evide_dashboard/Domain/services/websocket_services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:path/path.dart' as p;

part 'contents_event.dart';
part 'contents_state.dart';

class ContentsBloc extends Bloc<ContentsEvent, ContentsState> {
  final WebSocketS3Service wsService;

  ContentsBloc(this.wsService) : super(ContentsInitial()) {
    /// Handle file upload
    on<UploadFileEvent>((event, emit) async {
      // Get current uploads
      List<UploadStatus> currentUploads = [];
      if (state is UploadingFilesState) {
        currentUploads = List.from((state as UploadingFilesState).uploads);
      }

      final fileName = event.filePath.split('/').last;
      final newUpload = UploadStatus(filename: fileName);

      // Add new upload to list
      currentUploads.add(newUpload);
      emit(UploadingFilesState(currentUploads));

      try {
        await wsService.uploadFile(
          filePath: event.filePath,
          onProgress: (progress) {
            final updated = currentUploads.map((u) {
              if (u.filename == fileName) {
                return u.copyWith(progress: progress);
              }
              return u;
            }).toList();
            emit(UploadingFilesState(updated));
          },
          onComplete: (uploadedFile) {
            // After successful upload, dispatch fetch event
            add(const FetchFilesEvent());
            print('✅ File uploaded: ${uploadedFile.url}, refreshing...');
          },

          onError: (error) {
            final updated = currentUploads.map((u) {
              if (u.filename == fileName) {
                return u.copyWith(error: error.toString());
              }
              return u;
            }).toList();
            emit(UploadingFilesState(updated));
            print('❌ Upload error: $error');
          },
        );
      } catch (e) {
        final updated = currentUploads.map((u) {
          if (u.filename == fileName) {
            return u.copyWith(error: e.toString());
          }
          return u;
        }).toList();
        emit(UploadingFilesState(updated));
      }
    });

    /// AddUploadedFileEvent
    on<AddUploadedFileEvent>((event, emit) {
      final currentState = state;
      if (currentState is FilesListLoadedState) {
        final updatedFiles = List<UploadedFile>.from(currentState.files)
          ..insert(0, event.file);
        emit(FilesListLoadedState(updatedFiles));
      } else {
        emit(FilesListLoadedState([event.file]));
      }
    });

    /// Handle fetch files
    on<FetchFilesEvent>((event, emit) async {
      emit(ContentLoadingState());
      try {
        print('📡 Fetching uploaded files with thumbnails...');

        final files = await wsService.fetchUploadedFiles();

        final filesWithThumbnails = files.map((file) {
          return UploadedFile(
            filename: file.filename,
            url: file.url,
            thumbnail: file.thumbnail.isNotEmpty ? file.thumbnail : file.url,
            size: file.size,
          );
        }).toList();
print('file name ${filesWithThumbnails.first.filename}');
        emit(FilesListLoadedState(filesWithThumbnails));
        print('✅ Files fetched: ${filesWithThumbnails.length} items');
      } on HandshakeException {
        emit(
          const ContentErrorState(
            message: "Secure connection failed (Handshake Error)",
          ),
        );
      } on SocketException {
        emit(
          const ContentErrorState(
            message: "Network error while fetching files",
          ),
        );
      } catch (e) {
        emit(ContentErrorState(message: e.toString()));
      }
    });

    /// Handle file delete
    on<DeleteFileEvent>((event, emit) async {
      emit(ContentLoadingState());
      try {
        final filenames = event.files.map((f) => f.filename).toList();

        await wsService.deleteFiles(filenames);

        final updatedFiles = await wsService.fetchUploadedFiles();
        emit(FilesListLoadedState(updatedFiles));
        print('✅ Deleted files: ${filenames.join(', ')}');
      } catch (e) {
        emit(ContentErrorState(message: e.toString()));
        print('❌ File deletion error: $e');
      }
    });
  }
}
