part of 'contents_bloc.dart';

abstract class ContentsEvent extends Equatable {
  const ContentsEvent();

  @override
  List<Object?> get props => [];
}

/// Event to upload a file
class UploadFileEvent extends ContentsEvent {
  final String filePath;

  const UploadFileEvent(this.filePath);

  @override
  List<Object?> get props => [filePath];
}

/// Event to fetch all uploaded files
class FetchFilesEvent extends ContentsEvent {
  const FetchFilesEvent();
}
/// Event to delete files
class DeleteFileEvent extends ContentsEvent {
  final List<UploadedFile> files;

  const DeleteFileEvent(this.files);

  @override
  List<Object?> get props => [files];
}
class AddUploadedFileEvent extends ContentsEvent {
  final UploadedFile file;
  const AddUploadedFileEvent(this.file);
}
