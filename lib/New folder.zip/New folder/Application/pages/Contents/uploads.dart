import 'package:evide_dashboard/Application/pages/Contents/bloc/contents_bloc.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class UploadWrapper extends StatelessWidget {
  const UploadWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
      value: BlocProvider.of<ContentsBloc>(context),
      child: const Uploads(),
    );
  }
}

class Uploads extends StatefulWidget {
  const Uploads({super.key});

  @override
  State<Uploads> createState() => _UploadsState();
}

class _UploadsState extends State<Uploads> {
  Future<void> pickAndUploadFiles() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.media,
      allowMultiple: true,
    );

    if (result == null || result.files.isEmpty) return;

    for (var picked in result.files) {
      if (picked.path != null) {
        context.read<ContentsBloc>().add(UploadFileEvent(picked.path!));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<ContentsBloc, ContentsState>(
      listener: (context, state) {
        if (state is UploadingFilesState) {
          // still uploading
        } else if (state is FilesListLoadedState) {
          // ✅ When uploads finish, close dialog automatically
          Navigator.of(context).pop();
        }
      },
      child: BlocBuilder<ContentsBloc, ContentsState>(
        builder: (context, state) {
          List<UploadStatus> uploads = [];

          if (state is UploadingFilesState) {
            uploads = state.uploads;
          }

          return BlocBuilder<ContentsBloc, ContentsState>(
            builder: (context, state) {
              return AlertDialog(
                title: const Text("Upload Contents"),
                content: SizedBox(
                  width: 350,
                  height: 300,
                  child: Column(
                    children: [
                      ElevatedButton.icon(
                        onPressed: pickAndUploadFiles,
                        icon: const Icon(Icons.add),
                        label: const Text("Add Files"),
                      ),
                      const SizedBox(height: 16),
                      Expanded(
                        child: uploads.isEmpty
                            ? const Center(child: Text("No uploads yet"))
                            : ListView.builder(
                                itemCount: uploads.length,
                                itemBuilder: (context, index) {
                                  final u = uploads[index];
                                  return ListTile(
                                    leading: u.completed
                                        ? const Icon(
                                            Icons.check_circle,
                                            color: Colors.green,
                                          )
                                        : u.error != null
                                        ? const Icon(
                                            Icons.error,
                                            color: Colors.red,
                                          )
                                        : const Icon(Icons.upload),
                                    title: Text(u.filename),
                                    subtitle: u.error != null
                                        ? Text(
                                            "Error: ${u.error}",
                                            style: const TextStyle(
                                              color: Colors.red,
                                            ),
                                          )
                                        : u.completed
                                        ? Text("Uploaded: ${u.url}")
                                        : LinearProgressIndicator(
                                            value: u.progress / 100,
                                          ),
                                  );
                                },
                              ),
                      ),
                    ],
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                      // context.read<ContentsBloc>().add(FetchFilesEvent());
                    },
                    child: const Text("Close"),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}
