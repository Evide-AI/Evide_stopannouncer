import 'package:evide_dashboard/Application/pages/AddScreens/bloc/addscreen_bloc.dart';
import 'package:evide_dashboard/Application/pages/AssignContent/AssigntoScreens.dart';
import 'package:evide_dashboard/Application/widgets/custom_Textfield_widget.dart';
import 'package:evide_dashboard/Domain/services/websocket_services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';

class AddscreenWrapper extends StatelessWidget {
  const AddscreenWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          AddscreenBloc(service: WebSocketS3Service('ws://166.0.244.214:8081')),
      child: const Addscreen(),
    );
  }
}

class Addscreen extends StatefulWidget {
  const Addscreen({super.key});

  @override
  State<Addscreen> createState() => _AddscreenState();
}

class _AddscreenState extends State<Addscreen> {
  final Set<String> selectedIds = {};
  bool isSelectionMode = false;

  @override
  void initState() {
    super.initState();
    // Delay the bloc call to ensure the provider is properly initialized
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AddscreenBloc>().add(LoadScreens());
    });
  }

  void _showAddDialog() {
    final outerContext = context;
    final pairingController = TextEditingController();
    final nameController = TextEditingController();
    final descController = TextEditingController();

    showDialog(
      context: outerContext,
      barrierDismissible: false,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        elevation: 8,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.blue.shade50, Colors.white],
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade100,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(
                      Icons.add_box,
                      color: Colors.blue.shade700,
                      size: 24,
                    ),
                  ),
                  const Gap(12),
                  Text(
                    "Add New Screen",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey.shade800,
                    ),
                  ),
                ],
              ),
              const Gap(24),
              CustomTextformWidget(
                controller: pairingController,
                hinttext: 'Enter pairing code',
                labelText: 'Pairing Code',
                keyboardType: TextInputType.text,
                isPassword: false,
                validator: (value) => value == null || value.isEmpty
                    ? 'Please enter Pairing Code'
                    : null,
              ),
              const Gap(16),
              CustomTextformWidget(
                controller: nameController,
                hinttext: 'Enter screen name',
                labelText: 'Screen Name',
                keyboardType: TextInputType.text,
                isPassword: false,
                validator: (value) => value == null || value.isEmpty
                    ? 'Please enter screen name'
                    : null,
              ),
              const Gap(16),
              CustomTextformWidget(
                controller: descController,
                hinttext: 'Enter description (optional)',
                labelText: 'Description',
                keyboardType: TextInputType.text,
                isPassword: false,
                validator: null,
              ),
              const Gap(24),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 12,
                      ),
                    ),
                    child: Text(
                      "Cancel",
                      style: TextStyle(color: Colors.grey.shade600),
                    ),
                  ),
                  const Gap(12),
                  ElevatedButton(
                    onPressed: () {
                      if (pairingController.text.trim().isEmpty ||
                          nameController.text.trim().isEmpty) {
                        return;
                      }
                      outerContext.read<AddscreenBloc>().add(
                        AddScreenPressed(
                          pairingCode: pairingController.text.trim(),
                          screenName: nameController.text.trim(),
                          description: descController.text.trim().isEmpty
                              ? null
                              : descController.text.trim(),
                        ),
                      );
                      Navigator.pop(context);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue.shade600,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      elevation: 2,
                    ),
                    child: const Text(
                      "Save",
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _deleteSelected() {
    final outerContext = context;
    showDialog(
      context: outerContext,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          title: Row(
            children: [
              Icon(Icons.warning, color: Colors.red.shade600),
              const Gap(10),
              const Text("Confirm Delete"),
            ],
          ),
          content: Text(
            "Are you sure you want to delete ${selectedIds.length} selected screen(s)? This action cannot be undone.",
            style: const TextStyle(fontSize: 16),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                "Cancel",
                style: TextStyle(color: Colors.grey.shade600),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                outerContext.read<AddscreenBloc>().add(
                  DeleteSelectedScreens(screenIds: selectedIds.toList()),
                );
                setState(() {
                  selectedIds.clear();
                  isSelectionMode = false;
                });
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red.shade600,
                foregroundColor: Colors.white,
              ),
              child: const Text("Delete"),
            ),
          ],
        );
      },
    );
  }

  void _toggleSelection(String id) {
    setState(() {
      if (selectedIds.contains(id)) {
        selectedIds.remove(id);
        if (selectedIds.isEmpty) {
          isSelectionMode = false;
        }
      } else {
        selectedIds.add(id);
        if (!isSelectionMode) {
          isSelectionMode = true;
        }
      }
    });
  }

  void _cancelSelection() {
    setState(() {
      selectedIds.clear();
      isSelectionMode = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        foregroundColor: Colors.grey.shade800,
        title: isSelectionMode
            ? Text("${selectedIds.length} Selected")
            : const Text(
                "Screens",
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
        leading: isSelectionMode
            ? IconButton(
                icon: const Icon(Icons.close),
                onPressed: _cancelSelection,
              )
            : null,
        actions: [
          if (!isSelectionMode)
            BlocBuilder<AddscreenBloc, AddscreenState>(
              builder: (context, state) {
                if (state is ScreensLoaded && state.items.isNotEmpty) {
                  return Container(
                    margin: const EdgeInsets.only(right: 16),
                    child: ElevatedButton.icon(
                      onPressed: _showAddDialog,
                      icon: const Icon(Icons.add, size: 20),
                      label: const Text('Add Screen'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue.shade600,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                        elevation: 2,
                      ),
                    ),
                  );
                }
                return const SizedBox.shrink();
              },
            ),
          if (isSelectionMode)
            IconButton(
              icon: Icon(Icons.delete, color: Colors.red.shade600),
              onPressed: selectedIds.isNotEmpty ? _deleteSelected : null,
            ),
        ],
      ),
      body: BlocConsumer<AddscreenBloc, AddscreenState>(
        listenWhen: (prev, curr) => curr is ScreensFailure,
        listener: (context, state) {
          if (state is ScreensFailure) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Row(
                  children: [
                    const Icon(Icons.error, color: Colors.white),
                    const Gap(10),
                    Expanded(child: Text(state.error)),
                  ],
                ),
                backgroundColor: Colors.red.shade600,
                duration: const Duration(seconds: 5),
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            );
          }
        },
        buildWhen: (prev, curr) => curr is! ScreensFailure,
        builder: (context, state) {
          if (state is ScreensLoading) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(
                      Colors.blue.shade600,
                    ),
                  ),
                  const Gap(16),
                  Text(
                    "Loading screens...",
                    style: TextStyle(color: Colors.grey.shade600, fontSize: 16),
                  ),
                ],
              ),
            );
          }

          if (state is ScreensLoaded) {
            final items = state.items;

            if (items.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 200,
                      height: 200,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [Colors.blue.shade100, Colors.green.shade100],
                        ),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            blurRadius: 20,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: _showAddDialog,
                          borderRadius: BorderRadius.circular(20),
                          child: const Center(
                            child: Icon(
                              Icons.add,
                              size: 60,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const Gap(24),
                    Text(
                      "No Screens Yet",
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey.shade700,
                      ),
                    ),
                    const Gap(8),
                    Text(
                      "Tap the card above to add your first screen",
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey.shade500,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              );
            }

            return GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16.0,
                crossAxisSpacing: 16.0,
                childAspectRatio: 0.85,
              ),
              padding: const EdgeInsets.all(16.0),
              itemCount: items.length,
              itemBuilder: (context, index) {
                final item = items[index];
                final isSelected = selectedIds.contains(item.id);

                return AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  transform: Matrix4.identity()..scale(isSelected ? 0.95 : 1.0),
                  child: GestureDetector(
                    onLongPress: () => _toggleSelection(item.id),
                    child: Card(
                      elevation: isSelected ? 8 : 3,
                      shadowColor: isSelected
                          ? Colors.blue.withOpacity(0.3)
                          : Colors.black.withOpacity(0.1),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: isSelected
                            ? BorderSide(color: Colors.blue.shade600, width: 2)
                            : BorderSide.none,
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: isSelected
                                ? [Colors.blue.shade50, Colors.blue.shade100]
                                : [Colors.white, Colors.grey.shade50],
                          ),
                        ),
                        child: Material(
                          color: Colors.transparent,
                          child: InkWell(
                            onTap: () {
                              if (isSelectionMode) {
                                _toggleSelection(item.id);
                              } else {
                                Navigator.pushNamed(
                                  context,
                                  '/assigncontent',
                                  arguments: item,
                                );
                              }
                            },
                            borderRadius: BorderRadius.circular(16),
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(20),
                                        decoration: BoxDecoration(
                                          color: Colors.blue.shade100,
                                          borderRadius: BorderRadius.circular(
                                            20,
                                          ),
                                        ),
                                        child: Icon(
                                          Icons.tv,
                                          size: 60,
                                          color: Colors.blue.shade600,
                                        ),
                                      ),
                                      if (isSelected)
                                        Positioned(
                                          top: 0,
                                          right: 0,
                                          child: Container(
                                            padding: const EdgeInsets.all(4),
                                            decoration: BoxDecoration(
                                              color: Colors.blue.shade600,
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                            child: const Icon(
                                              Icons.check,
                                              size: 16,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                  const Gap(16),
                                  Text(
                                    item.screenName,
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.grey.shade800,
                                    ),
                                    textAlign: TextAlign.center,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  if (item.description != null) ...[
                                    const Gap(8),
                                    Text(
                                      item.description!,
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey.shade600,
                                      ),
                                      textAlign: TextAlign.center,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            );
          }

          return const SizedBox.shrink();
        },
      ),
      // floatingActionButton: BlocBuilder<AddscreenBloc, AddscreenState>(
      //   builder: (context, state) {
      //     if (state is ScreensLoaded && state.items.isNotEmpty && !isSelectionMode) {
      //       return FloatingActionButton.extended(
      //         onPressed: _showAddDialog,
      //         backgroundColor: Colors.blue.shade600,
      //         foregroundColor: Colors.white,
      //         icon: const Icon(Icons.add),
      //         label: const Text("Add Screen"),
      //         elevation: 4,
      //       );
      //     }
      //     return const SizedBox.shrink();
      //   },
      // ),
    );
  }
}
