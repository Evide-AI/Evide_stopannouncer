part of 'addscreen_bloc.dart';

sealed class AddscreenEvent extends Equatable {
  const AddscreenEvent();

  @override
  List<Object> get props => [];
}

class LoadScreens extends AddscreenEvent {}

class AddScreenPressed extends AddscreenEvent {
  final String pairingCode;
  final String screenName;
  final String? description;

  AddScreenPressed({
    required this.pairingCode,
    required this.screenName,
    this.description,
  });

  @override
  List<Object> get props => [pairingCode, screenName, ?description];
}

class DeleteSelectedScreens extends AddscreenEvent {
  final List<String> screenIds;

  const DeleteSelectedScreens({required this.screenIds});

  @override
  List<Object> get props => [screenIds];
}

// ===================== File Upload Event =====================
class UploadAndAssignContent extends AddscreenEvent {
  final String filePath;
  final String pairingCode;

  const UploadAndAssignContent({
    required this.filePath,
    required this.pairingCode,
  });

  @override
  List<Object> get props => [filePath, pairingCode];
}

// Internal event for WebSocket updates
