part of 'addscreen_bloc.dart';

sealed class AddscreenState extends Equatable {
  const AddscreenState();

  @override
  List<Object> get props => [];
}

class ScreensInitial extends AddscreenState {}

class ScreensLoading extends AddscreenState {}

class ScreensLoaded extends AddscreenState {
  final List<ScreenItem> items;

  const ScreensLoaded({required this.items});

  @override
  List<Object> get props => [items];
}

class ScreensFailure extends AddscreenState {
  final String error;

  const ScreensFailure(this.error);

  @override
  List<Object> get props => [error];
}

// ===================== File Upload States =====================
class UploadingFileScreenState extends AddscreenState {
  final double progress;

  const UploadingFileScreenState({required this.progress});

  @override
  List<Object> get props => [progress];
}

class FileUploadedScreenState extends AddscreenState {
  final UploadedFile file;

  const FileUploadedScreenState(this.file);

  @override
  List<Object> get props => [file];
}
