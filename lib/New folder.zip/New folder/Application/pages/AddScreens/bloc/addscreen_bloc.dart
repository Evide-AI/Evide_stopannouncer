import 'dart:async';
import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:evide_dashboard/Domain/services/websocket_services.dart';

part 'addscreen_event.dart';
part 'addscreen_state.dart';

class AddscreenBloc extends Bloc<AddscreenEvent, AddscreenState> {
  final WebSocketS3Service service;
  late final StreamSubscription _screenSub;

  AddscreenBloc({required this.service}) : super(ScreensInitial()) {
    // Listen to WebSocket real-time updates
    _screenSub = service.messages.listen((data) {
      switch (data['type']) {
        case 'screen_update':
          final screensData = (data['screens'] as List)
              .map((e) => ScreenItem.fromJson(e))
              .toList();
          add(_ScreensUpdated(screensData));
          break;

        case 'screen_registered':
          if (state is ScreensLoaded) {
            final current = List<ScreenItem>.from(
              (state as ScreensLoaded).items,
            );
            current.add(ScreenItem.fromJson(data['screen']));
            add(_ScreensUpdated(current));
          }
          break;

        case 'screen_deleted':
        case 'screen_removed':
          if (state is ScreensLoaded) {
            final current = List<ScreenItem>.from(
              (state as ScreensLoaded).items,
            )..removeWhere((s) => s.id == data['screenId']);
            add(_ScreensUpdated(current));
          }
          break;
      }
    });

    // ===================== Load Screens =====================
    on<LoadScreens>((event, emit) async {
      emit(ScreensLoading());
      try {
        final screens = await service.fetchScreens();
        emit(ScreensLoaded(items: screens));
      } on HandshakeException {
        emit(
          const ScreensFailure("Secure connection failed (Handshake Error)"),
        );
      } on SocketException {
        emit(const ScreensFailure("Network error while fetching screens"));
      } catch (e) {
        emit(ScreensFailure(e.toString()));
        print(
          'error occured when the screen is loading........${e.toString()}',
        );
      }
    });

    // ===================== Internal Real-Time Update =====================
    on<_ScreensUpdated>((event, emit) {
      emit(ScreensLoaded(items: event.screens));
    });

    // ===================== Add Screen =====================
    on<AddScreenPressed>((event, emit) async {
      if (event.screenName.trim().isEmpty || event.pairingCode.trim().isEmpty) {
        emit(ScreensFailure('Screen name and pairing code cannot be empty.'));
        return;
      }

      emit(ScreensLoading());

      try {
        await service.addScreen(
          event.screenName,
          description: event.description,
          pairingCode: event.pairingCode,
        );

        final screens = await service.fetchScreens();
        emit(ScreensLoaded(items: screens));
      } on Exception catch (e) {
        final errorMsg = e.toString();

        // If backend rejected for duplicate pairing code
        if (errorMsg.contains('Pairing code already exists')) {
          // Keep the current list instead of staying in loading state
          if (state is ScreensLoaded) {
            emit(ScreensFailure('Pairing code already exists.'));
            emit(state); // go back to previous loaded state
          } else {
            emit(ScreensFailure('Pairing code already exists.'));
          }
        } else {
          emit(ScreensFailure(errorMsg));
        }
      }
    });

    // ===================== Delete Selected Screens =====================
    on<DeleteSelectedScreens>((event, emit) async {
      if (event.screenIds.isEmpty) {
        emit(ScreensFailure('No screens selected for deletion.'));
        return;
      }

      emit(ScreensLoading());
      print('loading for delete......');
      try {
        for (var id in event.screenIds) {
          await service.deleteScreen(id);
          print('the screen is deleted......${id}');
        }

        final screens = await service.fetchScreens();
        emit(ScreensLoaded(items: screens));
        // Real-time stream will update automatically
      } catch (e) {
        emit(ScreensFailure(e.toString()));
      }
    });
  }

  @override
  Future<void> close() {
    _screenSub.cancel();
    return super.close();
  }
}

// Internal event for WebSocket updates
class _ScreensUpdated extends AddscreenEvent {
  final List<ScreenItem> screens;

  const _ScreensUpdated(this.screens);

  @override
  List<Object> get props => [screens];
}
