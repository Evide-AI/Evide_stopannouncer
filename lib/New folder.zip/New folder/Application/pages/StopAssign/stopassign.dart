// import 'package:evide_dashboard/Application/cores/colors.dart';
// import 'package:evide_dashboard/Application/pages/Stops/bloc/stops_bloc.dart';
// import 'package:evide_dashboard/Domain/services/websocket_services.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:gap/gap.dart';

// class StopToscreenWrapper extends StatelessWidget {
//   final String pairingCode;
//   const StopToscreenWrapper({super.key, required this.pairingCode});

//   @override
//   Widget build(BuildContext context) {
//     return BlocProvider(
//       create: (context) =>
//           StopsBloc(WebSocketS3Service('ws://166.0.244.214:8081')),
//       child: Builder(
//         builder: (context) {
//           return ScreenStopAssignmentPage(pairingCode: pairingCode);
//         },
//       ),
//     );
//   }
// }

// class ScreenStopAssignmentPage extends StatefulWidget {
//   final String pairingCode;
//   const ScreenStopAssignmentPage({super.key, required this.pairingCode});

//   @override
//   State<ScreenStopAssignmentPage> createState() =>
//       _ScreenStopAssignmentPageState();
// }

// class _ScreenStopAssignmentPageState extends State<ScreenStopAssignmentPage>
//     with TickerProviderStateMixin {
//   String? _pairingCode;
//   List<String> _selectedStops = [];
//   final TextEditingController _searchController = TextEditingController();
//   String _searchQuery = '';
//   bool _isAssigning = false;

//   // ✅ FIXED: Store all stops in widget state to maintain reference
//   List<Stop> _allStops = [];

//   @override
//   void initState() {
//     super.initState();
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       // Fetch all stops and screen-specific stops
//       context.read<StopsBloc>().add(FetchStopsEvent());
//       context.read<StopsBloc>().add(FetchScreenStopsEvent(widget.pairingCode));
//     });
//   }

//   @override
//   void dispose() {
//     _searchController.dispose();
//     super.dispose();
//   }

//   @override
//   void didChangeDependencies() {
//     final args = ModalRoute.of(context)?.settings.arguments as String?;
//     if (args != null) {
//       _pairingCode = args;
//     }
//     super.didChangeDependencies();
//   }

//   void _toggleStopSelection(String stopId) {
//     setState(() {
//       if (_selectedStops.contains(stopId)) {
//         _selectedStops.remove(stopId);
//       } else {
//         _selectedStops.add(stopId);
//       }
//     });
//   }

//   void _assignStopsToScreen() async {
//     if (_selectedStops.isEmpty) {
//       _showSnackBar('Please select at least one stop', Colors.orange);
//       return;
//     }

//     setState(() {
//       _isAssigning = true;
//     });

//     try {
//       context.read<StopsBloc>().add(
//         AssignStopsToScreenEvent(widget.pairingCode, _selectedStops),
//       );

//       // ✅ FIXED: Refetch the screen stops after assignment
//       context.read<StopsBloc>().add(FetchScreenStopsEvent(widget.pairingCode));

//       setState(() {
//         _selectedStops.clear();
//       });

//       _showSnackBar('Stops assigned successfully!', Colors.green);
//     } catch (e) {
//       _showSnackBar('Failed to assign stops', Colors.red);
//     } finally {
//       setState(() {
//         _isAssigning = false;
//       });
//     }
//   }

//   void _unassignStop(String stopId) {
//     context.read<StopsBloc>().add(
//       UnassignStopFromScreenEvent(widget.pairingCode, stopId),
//     );

//     // ✅ FIXED: Refetch the screen stops after unassignment
//     context.read<StopsBloc>().add(FetchScreenStopsEvent(widget.pairingCode));

//     _showSnackBar('Stop removed successfully!', Colors.orange);
//   }

//   void _showSnackBar(String message, Color color) {
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text(message),
//         backgroundColor: color,
//         behavior: SnackBarBehavior.floating,
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
//       ),
//     );
//   }

//   Widget _buildAssignedStopCard(Stop stop) {
//     return Container(
//       margin: EdgeInsets.only(bottom: 8),
//       decoration: BoxDecoration(
//         gradient: LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [Colors.green[50]!, Colors.green[100]!],
//         ),
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(color: Colors.green[300]!, width: 2),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.green.withOpacity(0.1),
//             blurRadius: 8,
//             offset: Offset(0, 2),
//           ),
//         ],
//       ),
//       child: ListTile(
//         contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//         leading: Container(
//           width: 48,
//           height: 48,
//           decoration: BoxDecoration(
//             gradient: LinearGradient(
//               colors: [Colors.green[400]!, Colors.green[600]!],
//             ),
//             borderRadius: BorderRadius.circular(24),
//           ),
//           child: Icon(Icons.check_circle, color: Colors.white, size: 24),
//         ),
//         title: Row(
//           children: [
//             Expanded(
//               child: Text(
//                 stop.stopName,
//                 style: TextStyle(
//                   fontWeight: FontWeight.bold,
//                   color: Colors.green[800],
//                 ),
//               ),
//             ),
//             Container(
//               padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//               decoration: BoxDecoration(
//                 color: Colors.green[600],
//                 borderRadius: BorderRadius.circular(12),
//               ),
//               child: Text(
//                 'ASSIGNED',
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 10,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ],
//         ),
//         subtitle: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Gap(4),
//             Text(
//               'Stop ID: ${stop.id}',
//               style: TextStyle(
//                 color: Colors.green[700],
//                 fontSize: 13,
//                 fontWeight: FontWeight.w500,
//               ),
//             ),
//             Gap(2),
//             Text(
//               'Lat: ${stop.latitude}, Lng: ${stop.longitude}',
//               style: TextStyle(color: Colors.green[600], fontSize: 12),
//             ),
//           ],
//         ),
//         trailing: IconButton(
//           icon: Container(
//             padding: EdgeInsets.all(6),
//             decoration: BoxDecoration(
//               color: Colors.red[100],
//               borderRadius: BorderRadius.circular(20),
//             ),
//             child: Icon(
//               Icons.remove_circle_outline,
//               color: Colors.red[600],
//               size: 20,
//             ),
//           ),
//           onPressed: () => _showUnassignDialog(stop),
//         ),
//       ),
//     );
//   }

//   Widget _buildUnassignedStopCard(Stop stop, List<String> assignedStopIds) {
//     final isSelected = _selectedStops.contains(stop.id);

//     return Container(
//       margin: EdgeInsets.only(bottom: 8),
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(12),
//         border: Border.all(
//           color: isSelected ? Colors.blue[300]! : Colors.grey[200]!,
//           width: isSelected ? 2 : 1,
//         ),
//         boxShadow: [
//           BoxShadow(
//             color: Colors.black.withOpacity(0.05),
//             blurRadius: 8,
//             offset: Offset(0, 2),
//           ),
//         ],
//       ),
//       child: ListTile(
//         contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//         leading: Container(
//           width: 48,
//           height: 48,
//           decoration: BoxDecoration(
//             color: isSelected ? Colors.blue[100] : Colors.grey[100],
//             borderRadius: BorderRadius.circular(24),
//           ),
//           child: Icon(
//             Icons.bus_alert,
//             color: isSelected ? Colors.blue[700] : Colors.grey[600],
//             size: 24,
//           ),
//         ),
//         title: Text(
//           stop.stopName,
//           style: TextStyle(
//             fontWeight: FontWeight.w600,
//             color: Colors.grey[800],
//           ),
//         ),
//         subtitle: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Gap(4),
//             Text(
//               'Stop ID: ${stop.id}',
//               style: TextStyle(color: Colors.grey[600], fontSize: 13),
//             ),
//             Gap(2),
//             Text(
//               'Lat: ${stop.latitude}, Lng: ${stop.longitude}',
//               style: TextStyle(color: Colors.grey[500], fontSize: 12),
//             ),
//           ],
//         ),
//         trailing: AnimatedContainer(
//           duration: Duration(milliseconds: 200),
//           width: 24,
//           height: 24,
//           decoration: BoxDecoration(
//             color: isSelected ? Colors.blue[600] : Colors.transparent,
//             border: Border.all(
//               color: isSelected ? Colors.blue[600]! : Colors.grey[400]!,
//               width: 2,
//             ),
//             borderRadius: BorderRadius.circular(12),
//           ),
//           child: isSelected
//               ? Icon(Icons.check, color: Colors.white, size: 16)
//               : null,
//         ),
//         onTap: () => _toggleStopSelection(stop.id),
//       ),
//     );
//   }

//   void _showUnassignDialog(Stop stop) {
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(16),
//           ),
//           title: Text(
//             'Remove Stop',
//             style: TextStyle(fontWeight: FontWeight.bold),
//           ),
//           content: Text(
//             'Are you sure you want to remove "${stop.stopName}" from this screen?',
//           ),
//           actions: [
//             TextButton(
//               child: Text('Cancel'),
//               onPressed: () => Navigator.of(context).pop(),
//             ),
//             ElevatedButton(
//               style: ElevatedButton.styleFrom(
//                 backgroundColor: Colors.red[600],
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(8),
//                 ),
//               ),
//               child: Text('Remove', style: TextStyle(color: Colors.white)),
//               onPressed: () {
//                 Navigator.of(context).pop();
//                 _unassignStop(stop.id);
//               },
//             ),
//           ],
//         );
//       },
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.grey[50],
//       appBar: AppBar(
//         elevation: 0,
//         backgroundColor: Colors.white,
//         foregroundColor: Colors.grey[800],
//         title: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Text(
//               'Assign Stops',
//               style: TextStyle(
//                 fontSize: 20,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.grey[800],
//               ),
//             ),
//             Text(
//               'Screen: ${widget.pairingCode}',
//               style: TextStyle(
//                 fontSize: 12,
//                 color: Colors.grey[600],
//                 fontWeight: FontWeight.normal,
//               ),
//             ),
//           ],
//         ),
//         actions: [
//           if (_selectedStops.isNotEmpty)
//             Container(
//               margin: EdgeInsets.only(right: 16),
//               padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//               decoration: BoxDecoration(
//                 color: Colors.blue[100],
//                 borderRadius: BorderRadius.circular(20),
//               ),
//               child: Text(
//                 '${_selectedStops.length} selected',
//                 style: TextStyle(
//                   color: Colors.blue[700],
//                   fontWeight: FontWeight.w600,
//                   fontSize: 12,
//                 ),
//               ),
//             ),
//         ],
//       ),
//       body: Column(
//         children: [
//           // Search Bar
//           Container(
//             margin: EdgeInsets.all(16),
//             padding: EdgeInsets.symmetric(horizontal: 16),
//             decoration: BoxDecoration(
//               color: Colors.white,
//               borderRadius: BorderRadius.circular(12),
//               boxShadow: [
//                 BoxShadow(
//                   color: Colors.black.withOpacity(0.05),
//                   blurRadius: 10,
//                   offset: Offset(0, 2),
//                 ),
//               ],
//             ),
//             child: TextField(
//               controller: _searchController,
//               onChanged: (value) {
//                 setState(() {
//                   _searchQuery = value.toLowerCase();
//                 });
//               },
//               decoration: InputDecoration(
//                 hintText: 'Search stops...',
//                 border: InputBorder.none,
//                 prefixIcon: Icon(Icons.search, color: Colors.grey[400]),
//                 suffixIcon: _searchQuery.isNotEmpty
//                     ? IconButton(
//                         icon: Icon(Icons.clear, color: Colors.grey[400]),
//                         onPressed: () {
//                           _searchController.clear();
//                           setState(() {
//                             _searchQuery = '';
//                           });
//                         },
//                       )
//                     : null,
//               ),
//             ),
//           ),

//           // Stops List
//           Expanded(
//             child: BlocBuilder<StopsBloc, StopsState>(
//               builder: (context, state) {
//                 if (state is StopsLoading) {
//                   return Center(
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         CircularProgressIndicator(color: Colors.blue[600]),
//                         Gap(16),
//                         Text(
//                           'Loading stops...',
//                           style: TextStyle(
//                             color: Colors.grey[600],
//                             fontSize: 16,
//                           ),
//                         ),
//                       ],
//                     ),
//                   );
//                 }

//                 if (state is StopsError) {
//                   return Center(
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Icon(
//                           Icons.error_outline,
//                           size: 64,
//                           color: Colors.grey[400],
//                         ),
//                         Gap(16),
//                         Text(
//                           'Error loading stops',
//                           style: TextStyle(
//                             fontSize: 18,
//                             fontWeight: FontWeight.w600,
//                             color: Colors.grey[700],
//                           ),
//                         ),
//                         Gap(8),
//                         Text(
//                           state.message,
//                           style: TextStyle(color: Colors.grey[600]),
//                         ),
//                         Gap(16),
//                         ElevatedButton(
//                           onPressed: () {
//                             context.read<StopsBloc>().add(FetchStopsEvent());
//                             context.read<StopsBloc>().add(
//                               FetchScreenStopsEvent(widget.pairingCode),
//                             );
//                           },
//                           child: Text('Retry'),
//                         ),
//                       ],
//                     ),
//                   );
//                 }

//                 // ✅ FIXED: Better state handling with stored all stops
//                 List<Stop> allStops = _allStops;
//                 List<Stop> assignedStops = [];

//                 if (state is StopsLoaded) {
//                   allStops = state.stops;
//                   _allStops = state.stops; // Store for later use
//                 } else if (state is ScreenStopsLoaded) {
//                   assignedStops = state.stops;
//                   // Use stored stops instead of trying to access previous state
//                   allStops = _allStops;
//                 } else if (state is ScreenStopsUpdated) {
//                   assignedStops = state.stops;
//                   allStops = _allStops;
//                 }

//                 // If we don't have all stops loaded, show loading
//                 if (allStops.isEmpty && assignedStops.isEmpty) {
//                   return Center(child: CircularProgressIndicator());
//                 }

//                 final assignedStopIds = assignedStops.map((s) => s.id).toList();
//                 final unassignedStops = allStops
//                     .where((stop) => !assignedStopIds.contains(stop.id))
//                     .toList();

//                 // Apply search filter
//                 final filteredAssigned = assignedStops.where((stop) {
//                   return stop.stopName.toLowerCase().contains(_searchQuery) ||
//                       stop.id.toString().contains(_searchQuery);
//                 }).toList();

//                 final filteredUnassigned = unassignedStops.where((stop) {
//                   return stop.stopName.toLowerCase().contains(_searchQuery) ||
//                       stop.id.toString().contains(_searchQuery);
//                 }).toList();

//                 // Debug prints
//                 print('All stops count: ${allStops.length}');
//                 print('Assigned stops count: ${assignedStops.length}');
//                 print('Filtered assigned count: ${filteredAssigned.length}');

//                 if (filteredAssigned.isEmpty && filteredUnassigned.isEmpty) {
//                   return Center(
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Icon(
//                           _searchQuery.isEmpty
//                               ? Icons.bus_alert
//                               : Icons.search_off,
//                           size: 64,
//                           color: Colors.grey[400],
//                         ),
//                         Gap(16),
//                         Text(
//                           _searchQuery.isEmpty
//                               ? 'No stops available'
//                               : 'No stops found',
//                           style: TextStyle(
//                             fontSize: 18,
//                             fontWeight: FontWeight.w600,
//                             color: Colors.grey[700],
//                           ),
//                         ),
//                         if (_searchQuery.isNotEmpty) ...[
//                           Gap(8),
//                           Text(
//                             'Try adjusting your search',
//                             style: TextStyle(color: Colors.grey[600]),
//                           ),
//                         ],
//                       ],
//                     ),
//                   );
//                 }

//                 return ListView(
//                   padding: EdgeInsets.symmetric(horizontal: 16),
//                   children: [
//                     // Assigned Stops Section
//                     if (filteredAssigned.isNotEmpty) ...[
//                       Container(
//                         padding: EdgeInsets.symmetric(
//                           vertical: 12,
//                           horizontal: 16,
//                         ),
//                         margin: EdgeInsets.only(bottom: 8),
//                         decoration: BoxDecoration(
//                           gradient: LinearGradient(
//                             colors: [Colors.green[600]!, Colors.green[700]!],
//                           ),
//                           borderRadius: BorderRadius.circular(12),
//                         ),
//                         child: Row(
//                           children: [
//                             Icon(
//                               Icons.check_circle,
//                               color: Colors.white,
//                               size: 20,
//                             ),
//                             Gap(8),
//                             Text(
//                               'Assigned Stops (${filteredAssigned.length})',
//                               style: TextStyle(
//                                 color: Colors.white, // ✅ Fixed color
//                                 fontWeight: FontWeight.bold,
//                                 fontSize: 16,
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                       ...filteredAssigned.map(
//                         (stop) => _buildAssignedStopCard(stop),
//                       ),
//                       Gap(16),
//                     ],

//                     // Unassigned Stops Section
//                     if (filteredUnassigned.isNotEmpty) ...[
//                       Container(
//                         padding: EdgeInsets.symmetric(
//                           vertical: 12,
//                           horizontal: 16,
//                         ),
//                         margin: EdgeInsets.only(bottom: 8),
//                         decoration: BoxDecoration(
//                           gradient: LinearGradient(
//                             colors: [Colors.blue[600]!, Colors.blue[700]!],
//                           ),
//                           borderRadius: BorderRadius.circular(12),
//                         ),
//                         child: Row(
//                           children: [
//                             Icon(
//                               Icons.add_circle,
//                               color: Colors.white,
//                               size: 20,
//                             ),
//                             Gap(8),
//                             Text(
//                               'Available Stops (${filteredUnassigned.length})',
//                               style: TextStyle(
//                                 color: Colors.white,
//                                 fontWeight: FontWeight.bold,
//                                 fontSize: 16,
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                       ...filteredUnassigned.map(
//                         (stop) =>
//                             _buildUnassignedStopCard(stop, assignedStopIds),
//                       ),
//                       Gap(80), // Space for FAB
//                     ],
//                   ],
//                 );
//               },
//             ),
//           ),
//         ],
//       ),

//       // Floating Action Button
//       floatingActionButton: AnimatedScale(
//         scale: _selectedStops.isNotEmpty ? 1.0 : 0.0,
//         duration: Duration(milliseconds: 200),
//         child: Container(
//           width: double.infinity,
//           margin: EdgeInsets.symmetric(horizontal: 16),
//           child: FloatingActionButton.extended(
//             onPressed: () {
//               context.read<StopsBloc>().add(
//                 AssignStopsToScreenEvent(widget.pairingCode, _selectedStops),
//               );
//               print('the stop data with 📓 ${widget.pairingCode}👽 ${_selectedStops}');
//             },
//             backgroundColor: Colors.blue[600],
//             foregroundColor: Colors.white,
//             elevation: 8,
//             icon: _isAssigning
//                 ? SizedBox(
//                     width: 20,
//                     height: 20,
//                     child: CircularProgressIndicator(
//                       color: Colors.white,
//                       strokeWidth: 2,
//                     ),
//                   )
//                 : Icon(Icons.assignment_turned_in),
//             label: Text(
//               _isAssigning
//                   ? 'Assigning...'
//                   : 'Assign ${_selectedStops.length} Stop${_selectedStops.length == 1 ? '' : 's'}',
//               style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
//             ),
//           ),
//         ),
//       ),
//       floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
//     );
//   }
// }
