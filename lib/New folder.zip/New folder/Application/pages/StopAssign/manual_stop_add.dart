import 'dart:io';
import 'package:evide_dashboard/Application/pages/StopAssign/bloc/stopassign_bloc.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ManualStopWrapper extends StatelessWidget {
  const ManualStopWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => StopassignBloc(),
      child: const ManualStopUploadPage(),
    );
  }
}

class ManualStopUploadPage extends StatefulWidget {
  const ManualStopUploadPage({super.key});
  @override
  State<ManualStopUploadPage> createState() => _ManualStopUploadPageState();
}

class _ManualStopUploadPageState extends State<ManualStopUploadPage> {
  final _formKey = GlobalKey<FormState>();
  final _pairingCodeController = TextEditingController();
  final _stopNameController = TextEditingController();
  final _latController = TextEditingController();
  final _lngController = TextEditingController();

  String? _audioFilePath;

  /// Pick audio file
  void _pickAudio() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (result != null && result.files.isNotEmpty) {
      _audioFilePath = result.files.first.path;
      setState(() {});
    }
  }

  /// Add stop to cache
  void _addStopToCache() {
    if (_formKey.currentState!.validate()) {
      context.read<StopassignBloc>().add(
        AddStopToCacheEvent(
          pairingCode: _pairingCodeController.text.trim(),
          stopName: _stopNameController.text.trim(),
          latitude: double.tryParse(_latController.text) ?? 0.0,
          longitude: double.tryParse(_lngController.text) ?? 0.0,
          audioFilePath: _audioFilePath,
        ),
      );

      _stopNameController.clear();  
      _latController.clear();
      _lngController.clear();
      _audioFilePath = null;
    }
  }

  /// Upload all cached stops
  void _uploadAllStops() {
    final pairingCode = _pairingCodeController.text.trim();
    if (pairingCode.isNotEmpty) {
      context.read<StopassignBloc>().add(
        UploadAllStopsEvent(pairingCode: pairingCode),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final pairingCode = _pairingCodeController.text.trim();

    return Scaffold(
      appBar: AppBar(title: const Text('Add Stops')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _pairingCodeController,
                    decoration: const InputDecoration(
                      labelText: 'Screen Pairing Code',
                    ),
                    validator: (v) => v!.isEmpty ? 'Required' : null,
                  ),
                  TextFormField(
                    controller: _stopNameController,
                    decoration: const InputDecoration(labelText: 'Stop Name'),
                    validator: (v) => v!.isEmpty ? 'Required' : null,
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: _latController,
                          decoration: const InputDecoration(
                            labelText: 'Latitude',
                          ),
                          keyboardType: TextInputType.number,
                          validator: (v) => v!.isEmpty ? 'Required' : null,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: TextFormField(
                          controller: _lngController,
                          decoration: const InputDecoration(
                            labelText: 'Longitude',
                          ),
                          keyboardType: TextInputType.number,
                          validator: (v) => v!.isEmpty ? 'Required' : null,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      ElevatedButton(
                        onPressed: _pickAudio,
                        child: const Text('Pick Audio'),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _audioFilePath != null
                              ? _audioFilePath!.split('/').last
                              : 'No audio selected',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  BlocConsumer<StopassignBloc, StopassignState>(
                    listener: (context, state) {
                      if (state is StopError) {
                        ScaffoldMessenger.of(
                          context,
                        ).showSnackBar(SnackBar(content: Text(state.message)));
                      } else if (state is StopUploadSuccess) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('All stops uploaded ✅')),
                        );
                      }
                    },
                    builder: (context, state) {
                      return Row(
                        children: [
                          ElevatedButton(
                            onPressed: state is StopUploading
                                ? null
                                : _addStopToCache,
                            child: const Text('Add Stop to Cache'),
                          ),
                          const SizedBox(width: 12),
                          if (state is StopCacheUpdated &&
                              state.cachedStops.isNotEmpty)
                            ElevatedButton(
                              onPressed: state is StopUploading
                                  ? null
                                  : _uploadAllStops,
                              child: state is StopUploading
                                  ? const CircularProgressIndicator()
                                  : const Text('Upload All Stops'),
                            ),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: BlocBuilder<StopassignBloc, StopassignState>(
                builder: (context, state) {
                  List<Map<String, dynamic>> cachedStops = [];
                  if (state is StopCacheUpdated)
                    cachedStops = state.cachedStops;

                  if (cachedStops.isEmpty) {
                    return const Center(child: Text('No cached stops yet'));
                  }

                  return ListView.builder(
                    itemCount: cachedStops.length,
                    itemBuilder: (context, index) {
                      final stop = cachedStops[index];
                      return ListTile(
                        title: Text(stop["stopName"]),
                        subtitle: Text(
                          "Lat: ${stop["latitude"]}, Lng: ${stop["longitude"]}",
                        ),
                        trailing: stop["stopUrl"] != ""
                            ? const Icon(Icons.audiotrack)
                            : null,
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
