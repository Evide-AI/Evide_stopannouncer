part of 'stopassign_bloc.dart';

abstract class StopassignEvent extends Equatable {
  const StopassignEvent();
  @override
  List<Object?> get props => [];
}

// Add stop to cache
class AddStopToCacheEvent extends StopassignEvent {
  final String pairingCode;
  final String stopName;
  final double latitude;
  final double longitude;
  final String? audioFilePath;

  const AddStopToCacheEvent({
    required this.pairingCode,
    required this.stopName,
    required this.latitude,
    required this.longitude,
    this.audioFilePath,
  });

  @override
  List<Object?> get props => [pairingCode, stopName, latitude, longitude, audioFilePath];
}

// Upload all cached stops to Firestore
class UploadAllStopsEvent extends StopassignEvent {
  final String pairingCode;

  const UploadAllStopsEvent({required this.pairingCode});

  @override
  List<Object?> get props => [pairingCode];
}
