import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';
import 'package:firebase_storage/firebase_storage.dart';

part 'stopassign_event.dart';
part 'stopassign_state.dart';

class StopassignBloc extends Bloc<StopassignEvent, StopassignState> {
  final List<Map<String, dynamic>> _cachedStops = [];

  StopassignBloc() : super(StopassignInitial()) {
    // on<AddStopToCacheEvent>(_onAddStopToCache);
    // on<UploadAllStopsEvent>(_onUploadAllStops);

    on<AddStopToCacheEvent>((event, emit) {
      _cachedStops.add({
        "stopName": event.stopName,
        "latitude": event.latitude,
        "longitude": event.longitude,
        "stopUrl": event.audioFilePath ?? "",
      });
      emit(StopCacheUpdated(List.from(_cachedStops))); // emit copy
    });

    on<UploadAllStopsEvent>((event, emit) async {
      emit(StopUploading());

      final firestore = FirebaseFirestore.instance;
      final batch = firestore.batch();

      // find screen doc
      final screens = await firestore
          .collection("Screens")
          .where("pairingCode", isEqualTo: event.pairingCode)
          .get();

      DocumentReference screenDoc;

      if (screens.docs.isNotEmpty) {
        screenDoc = screens.docs.first.reference;
        batch.update(screenDoc, {"stops": FieldValue.arrayUnion(_cachedStops)});
      } else {
        screenDoc = firestore.collection("Screens").doc();
        batch.set(screenDoc, {
          "pairingCode": event.pairingCode,
          "stops": _cachedStops,
        });
      }

      await batch.commit();

      _cachedStops.clear();
      emit(StopUploadSuccess());
    });

    //   final stopData = {
    //     "stopName": event.stopName,
    //     "latitude": event.latitude,
    //     "longitude": event.longitude,
    //     "stopUrl": audioUrl ?? "",
    //     "createdAt": DateTime.now().toIso8601String(),
    //   };

    //   _cachedStops.add(stopData);
    //   emit(StopCacheUpdated(List.from(_cachedStops))); // emit updated cache
    // }

    //   void _onUploadAllStops(
    //     UploadAllStopsEvent event,
    //     Emitter<StopassignState> emit,
    //   ) async {
    //     if (_cachedStops.isEmpty) return;
    //     emit(StopUploading());

    //     try {
    //       final screensRef = FirebaseFirestore.instance.collection("Screens");

    //       final query = await screensRef
    //           .where("pairingCode", isEqualTo: event.pairingCode)
    //           .limit(1)
    //           .get();

    //       if (query.docs.isNotEmpty) {
    //         final docId = query.docs.first.id;
    //         await screensRef.doc(docId).update({
    //           "stops": FieldValue.arrayUnion(_cachedStops),
    //         });
    //       } else {
    //         await screensRef.add({
    //           "pairingCode": event.pairingCode,
    //           "stops": _cachedStops,
    //           "createdAt": FieldValue.serverTimestamp(),
    //         });
    //       }

    //       _cachedStops.clear();
    //       emit(StopUploadSuccess());
    //     } catch (e) {
    //       emit(StopError(e.toString()));
    //     }
    //   }

    //   Future<String> _uploadAudioToStorage(
    //     String filePath,
    //     String pairingCode,
    //   ) async {
    //     final file = File(filePath);
    //     final fileName = filePath.split('/').last;
    //     final storagePath = "stopAudio/$pairingCode/$fileName";

    //     final ref = FirebaseStorage.instance.ref().child(storagePath);
    //     await ref.putFile(file);
    //     return storagePath;
    //   }
    // }
  }
}
