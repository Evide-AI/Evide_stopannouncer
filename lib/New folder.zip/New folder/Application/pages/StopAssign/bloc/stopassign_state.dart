part of 'stopassign_bloc.dart';

abstract class StopassignState extends Equatable {
  const StopassignState();
  @override
  List<Object?> get props => [];
}

class StopassignInitial extends StopassignState {}

class StopCacheUpdated extends StopassignState {
  final List<Map<String, dynamic>> cachedStops;
  const StopCacheUpdated(this.cachedStops);

  @override
  List<Object?> get props => [cachedStops];
}

class StopUploading extends StopassignState {}

class StopUploadSuccess extends StopassignState {}

class StopError extends StopassignState {
  final String message;
  const StopError(this.message);

  @override
  List<Object?> get props => [message];
}
