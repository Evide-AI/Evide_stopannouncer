import 'package:evide_dashboard/Application/pages/AssignContent/bloc/assigncontent_bloc.dart';
import 'package:evide_dashboard/Application/pages/StopAssign/stopassign.dart';
import 'package:evide_dashboard/Domain/services/websocket_services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gap/gap.dart';

class AssigncontentWrapper extends StatelessWidget {
  const AssigncontentWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) =>
          AssigncontentBloc(WebSocketS3Service('ws://166.0.244.214:8081')),
      child: const AssignContent(),
    );
  }
}

class AssignContent extends StatefulWidget {
  const AssignContent({super.key});

  @override
  State<AssignContent> createState() => _AssignContentState();
}

class _AssignContentState extends State<AssignContent>
    with TickerProviderStateMixin {
  ScreenItem? _screendata;
  List<String> _screenContents = []; // Local editable list
  List<UploadedFile> _allContents = [];
  bool _hasUnsavedChanges = false;
  late AnimationController _saveButtonController;
  late Animation<double> _saveButtonAnimation;

  @override
  void initState() {
    super.initState();
    _saveButtonController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _saveButtonAnimation = CurvedAnimation(
      parent: _saveButtonController,
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _saveButtonController.dispose();
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    final args = ModalRoute.of(context)?.settings.arguments as ScreenItem?;
    if (args != null) {
      _screendata = args;

      // Fetch contents for this screen
      context.read<AssigncontentBloc>().add(
        FetchScreenContents(_screendata!.pairingCode),
      );

      // Fetch all available contents
      context.read<AssigncontentBloc>().add(LoadContent());
    }
    super.didChangeDependencies();
  }

  void _deleteFromScreen(String filename) {
    setState(() {
      _screenContents.remove(filename);
      _hasUnsavedChanges = true;
      _saveButtonController.forward();
    });
  }

  void _addToScreen(String filename) {
    if (!_screenContents.contains(filename)) {
      setState(() {
        _screenContents.add(filename);
        _hasUnsavedChanges = true;
        _saveButtonController.forward();
      });
    }
  }

  void _onReorder(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) newIndex--;
      final item = _screenContents.removeAt(oldIndex);
      _screenContents.insert(newIndex, item);
      _hasUnsavedChanges = true;
      _saveButtonController.forward();
    });
  }

  void _saveChanges() {
    if (_screendata == null) return;
    context.read<AssigncontentBloc>().add(
      ReorderScreenContents(
        pairingCode: _screendata!.pairingCode,
        files: _screenContents,
      ),
    );
    setState(() {
      _hasUnsavedChanges = false;
      _saveButtonController.reverse();
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.white),
            Gap(8),
            Text("Changes saved successfully"),
          ],
        ),
        backgroundColor: Colors.green.shade600,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  String _formatFileSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<AssigncontentBloc, AssigncontentState>(
      listener: (context, state) {
        if (state is ScreenContentsLoaded) {
          setState(() {
            _screenContents = state.screenFiles;
            _hasUnsavedChanges = false;
            _saveButtonController.reverse();
          });
        }
        if (state is LoadContentState) {
          setState(() {
            _allContents = state.files;
          });
        }
        if (state is ScreenContentActionSuccess) {
          setState(() {
            _screenContents = state.updatedFiles;
            _hasUnsavedChanges = false;
            _saveButtonController.reverse();
          });
        }
      },
      builder: (context, state) {
        final pairingCode = _screendata?.pairingCode;
        final screenName = _screendata?.screenName ?? 'Unknown';

        return Scaffold(
          backgroundColor: Colors.grey.shade50,
          appBar: AppBar(
            elevation: 0,
            backgroundColor: Colors.white,
            foregroundColor: Colors.grey.shade800,
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Assign Content",
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18),
                ),
                Text(
                  screenName,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey.shade600,
                    fontWeight: FontWeight.normal,
                  ),
                ),
              ],
            ),
            actions: [
              Container(
                margin: const EdgeInsets.only(right: 16),
                child: AnimatedBuilder(
                  animation: _saveButtonAnimation,
                  builder: (context, child) {
                    return Transform.scale(
                      scale: 1.0 + (_saveButtonAnimation.value * 0.1),
                      child: ElevatedButton.icon(
                        onPressed: _hasUnsavedChanges ? _saveChanges : null,
                        icon: const Icon(Icons.save, size: 18),
                        label: const Text("Save"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _hasUnsavedChanges
                              ? Colors.green.shade600
                              : Colors.grey.shade400,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          elevation: _hasUnsavedChanges ? 3 : 1,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
          body: Column(
            children: [
              // Screen's Assigned Content Section (Top)
              Expanded(
                flex: 2,
                child: Container(
                  margin: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      // Header
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.blue.shade50,
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(16),
                            topRight: Radius.circular(16),
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.blue.shade100,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Icon(
                                Icons.tv,
                                color: Colors.blue.shade600,
                                size: 20,
                              ),
                            ),
                            const Gap(12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Screen Content",
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.blue.shade700,
                                    ),
                                  ),
                                  Text(
                                    "${_screenContents.length} file(s) assigned",
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.blue.shade600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            if (_hasUnsavedChanges)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: Colors.orange.shade100,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  "Unsaved",
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Colors.orange.shade700,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),

                      // Drag Target Area
                      Expanded(
                        child: DragTarget<String>(
                          onAccept: (filename) {
                            _addToScreen(filename);
                          },
                          builder: (context, candidateData, rejectedData) {
                            return AnimatedContainer(
                              duration: const Duration(milliseconds: 200),
                              decoration: BoxDecoration(
                                color: candidateData.isNotEmpty
                                    ? Colors.blue.shade50
                                    : Colors.white,
                                border: candidateData.isNotEmpty
                                    ? Border.all(
                                        color: Colors.blue.shade300,
                                        width: 2,
                                        style: BorderStyle.solid,
                                      )
                                    : null,
                                borderRadius: const BorderRadius.only(
                                  bottomLeft: Radius.circular(16),
                                  bottomRight: Radius.circular(16),
                                ),
                              ),
                              child: _screenContents.isEmpty
                                  ? Center(
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            candidateData.isNotEmpty
                                                ? Icons.add_circle
                                                : Icons.drag_indicator,
                                            size: 48,
                                            color: candidateData.isNotEmpty
                                                ? Colors.blue.shade600
                                                : Colors.grey.shade400,
                                          ),
                                          const Gap(8),
                                          Text(
                                            candidateData.isNotEmpty
                                                ? "Drop here to assign"
                                                : "Drag content here or tap files below",
                                            style: TextStyle(
                                              color: candidateData.isNotEmpty
                                                  ? Colors.blue.shade600
                                                  : Colors.grey.shade500,
                                              fontSize: 16,
                                              fontWeight:
                                                  candidateData.isNotEmpty
                                                  ? FontWeight.w600
                                                  : FontWeight.normal,
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ],
                                      ),
                                    )
                                  : ReorderableListView(
                                      onReorder: _onReorder,
                                      padding: const EdgeInsets.all(8),
                                      children: [
                                        for (
                                          int index = 0;
                                          index < _screenContents.length;
                                          index++
                                        )
                                          Container(
                                            key: ValueKey(
                                              _screenContents[index],
                                            ),
                                            margin: const EdgeInsets.only(
                                              bottom: 8,
                                            ),
                                            decoration: BoxDecoration(
                                              color: Colors.grey.shade50,
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                              border: Border.all(
                                                color: Colors.grey.shade200,
                                              ),
                                            ),
                                            child: ListTile(
                                              contentPadding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 12,
                                                    vertical: 4,
                                                  ),
                                              leading: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Container(
                                                    width: 24,
                                                    height: 24,
                                                    decoration: BoxDecoration(
                                                      color:
                                                          Colors.blue.shade100,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                            6,
                                                          ),
                                                    ),
                                                    child: Center(
                                                      child: Text(
                                                        "${index + 1}",
                                                        style: TextStyle(
                                                          fontSize: 12,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors
                                                              .blue
                                                              .shade700,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  const Gap(8),
                                                  ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          8,
                                                        ),
                                                    child: Image.network(
                                                      _allContents
                                                          .firstWhere(
                                                            (f) =>
                                                                f.filename ==
                                                                _screenContents[index],
                                                            orElse: () => UploadedFile(
                                                              filename:
                                                                  _screenContents[index],
                                                              thumbnail:
                                                                  "https://via.placeholder.com/50",
                                                              size: 0,
                                                              url: '',
                                                            ),
                                                          )
                                                          .thumbnail,
                                                      width: 40,
                                                      height: 40,
                                                      fit: BoxFit.cover,
                                                      errorBuilder:
                                                          (
                                                            context,
                                                            error,
                                                            stackTrace,
                                                          ) {
                                                            return Container(
                                                              width: 40,
                                                              height: 40,
                                                              color: Colors
                                                                  .grey
                                                                  .shade200,
                                                              child: Icon(
                                                                Icons
                                                                    .broken_image,
                                                                color: Colors
                                                                    .grey
                                                                    .shade400,
                                                                size: 20,
                                                              ),
                                                            );
                                                          },
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              title: Text(
                                                getCleanFileName(
                                                  _screenContents[index],
                                                ),
                                                style: const TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 14,
                                                ),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                              subtitle: Text(
                                                _formatFileSize(
                                                  _allContents
                                                      .firstWhere(
                                                        (f) =>
                                                            f.filename ==
                                                            _screenContents[index],
                                                        orElse: () => UploadedFile(
                                                          filename:
                                                              _screenContents[index],
                                                          thumbnail: "",
                                                          size: 0,
                                                          url: '',
                                                        ),
                                                      )
                                                      .size,
                                                ),
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  color: Colors.grey.shade600,
                                                ),
                                              ),
                                              trailing: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Icon(
                                                    Icons.drag_handle,
                                                    color: Colors.grey.shade400,
                                                    size: 20,
                                                  ),
                                                  const Gap(4),
                                                  PopupMenuButton<String>(
                                                    icon: Icon(
                                                      Icons.more_vert,
                                                      color:
                                                          Colors.grey.shade400,
                                                      size: 20,
                                                    ),
                                                    onSelected: (value) {
                                                      if (value == 'delete') {
                                                        _deleteFromScreen(
                                                          _screenContents[index],
                                                        );
                                                      }
                                                    },
                                                    itemBuilder: (context) => [
                                                      PopupMenuItem(
                                                        onTap: () {
                                                          context
                                                              .read<
                                                                AssigncontentBloc
                                                              >()
                                                              .add(
                                                                DeleteScreenContent(
                                                                  pairingCode:
                                                                      _screendata!
                                                                          .pairingCode,
                                                                  filename:
                                                                      _screenContents[index],
                                                                ),
                                                              );
                                                        },
                                                        value: 'delete',
                                                        child: Row(
                                                          children: [
                                                            Icon(
                                                              Icons.delete,
                                                              color: Colors
                                                                  .red
                                                                  .shade600,
                                                            ),
                                                            const Gap(8),
                                                            const Text(
                                                              "Remove",
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Divider
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(height: 1, color: Colors.grey.shade300),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Text(
                        "Available Content",
                        style: TextStyle(
                          color: Colors.grey.shade600,
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Container(height: 1, color: Colors.grey.shade300),
                    ),
                  ],
                ),
              ),

              // All Available Contents Section (Bottom)
              Expanded(
                flex: 3,
                child: Container(
                  margin: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      // Header
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.green.shade50,
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(16),
                            topRight: Radius.circular(16),
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: Colors.green.shade100,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Icon(
                                Icons.folder,
                                color: Colors.green.shade600,
                                size: 20,
                              ),
                            ),
                            const Gap(12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Available Files",
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.green.shade700,
                                    ),
                                  ),
                                  Text(
                                    "Drag to assign or tap to add",
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.green.shade600,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Files List
                      Expanded(
                        child: _allContents.isEmpty
                            ? Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.folder_open,
                                      size: 48,
                                      color: Colors.grey.shade400,
                                    ),
                                    const Gap(8),
                                    Text(
                                      "No content available",
                                      style: TextStyle(
                                        color: Colors.grey.shade500,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            : ListView.builder(
                                padding: const EdgeInsets.all(8),
                                itemCount: _allContents.length,
                                itemBuilder: (context, index) {
                                  final file = _allContents[index];
                                  final isAssigned = _screenContents.contains(
                                    file.filename,
                                  );

                                  return Container(
                                    margin: const EdgeInsets.only(bottom: 8),
                                    decoration: BoxDecoration(
                                      color: isAssigned
                                          ? Colors.blue.shade50
                                          : Colors.grey.shade50,
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(
                                        color: isAssigned
                                            ? Colors.blue.shade200
                                            : Colors.grey.shade200,
                                      ),
                                    ),
                                    child: Draggable<String>(
                                      data: file.filename,
                                      feedback: Material(
                                        elevation: 6,
                                        borderRadius: BorderRadius.circular(12),
                                        child: Container(
                                          width: 200,
                                          padding: const EdgeInsets.all(12),
                                          decoration: BoxDecoration(
                                            color: Colors.blue.shade100,
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(
                                                Icons.drag_indicator,
                                                color: Colors.blue.shade600,
                                                size: 16,
                                              ),
                                              const Gap(8),
                                              Flexible(
                                                child: Text(
                                                  getCleanFileName(
                                                    file.filename,
                                                  ),
                                                  style: TextStyle(
                                                    color: Colors.blue.shade700,
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 12,
                                                  ),
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      childWhenDragging: Opacity(
                                        opacity: 0.3,
                                        child: _buildFileListTile(
                                          file,
                                          isAssigned,
                                        ),
                                      ),
                                      child: _buildFileListTile(
                                        file,
                                        isAssigned,
                                      ),
                                    ),
                                  );
                                },
                              ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          // floatingActionButton: FloatingActionButton(
          //   onPressed: () {
          //     print('the pairing code ......................${pairingCode}');
          //     Navigator.push(
          //       context,
          //       MaterialPageRoute(
          //         builder: (ctx) =>
          //             StopToscreenWrapper(pairingCode: pairingCode!),
                      
          //       ),
          //     );
          //   },
          //   child: Icon(Icons.audio_file_outlined),
          // ),
        );
      },
    );
  }

  Widget _buildFileListTile(UploadedFile file, bool isAssigned) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.network(
          file.thumbnail,
          width: 40,
          height: 40,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) {
            return Container(
              width: 40,
              height: 40,
              color: Colors.grey.shade200,
              child: Icon(
                Icons.broken_image,
                color: Colors.grey.shade400,
                size: 20,
              ),
            );
          },
        ),
      ),
      title: Text(
        getCleanFileName(file.filename),
        style: TextStyle(
          fontWeight: FontWeight.w500,
          fontSize: 14,
          color: isAssigned ? Colors.blue.shade700 : Colors.grey.shade800,
        ),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      subtitle: Text(
        _formatFileSize(file.size),
        style: TextStyle(
          fontSize: 12,
          color: isAssigned ? Colors.blue.shade600 : Colors.grey.shade600,
        ),
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (isAssigned)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.blue.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                "Added",
                style: TextStyle(
                  fontSize: 10,
                  color: Colors.blue.shade700,
                  fontWeight: FontWeight.w500,
                ),
              ),
            )
          else
            Icon(
              Icons.add_circle_outline,
              color: Colors.green.shade600,
              size: 20,
            ),
        ],
      ),
      onTap: () {
        _addToScreen(file.filename);
      },
    );
  }
}

/// Helper to clean filename
String getCleanFileName(String fullPath) {
  return fullPath.split('-').last;
}
