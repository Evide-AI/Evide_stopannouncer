part of 'assigncontent_bloc.dart';

abstract class AssigncontentState extends Equatable {
  const AssigncontentState();

  @override
  List<Object?> get props => [];
}

class AssigncontentInitial extends AssigncontentState {}

/// State while loading files
class LoadingContentstate extends AssigncontentState {}

/// Error state
class LoadingcontentError extends AssigncontentState {
  final String message;
  const LoadingcontentError({required this.message});

  @override
  List<Object?> get props => [message];
}

/// All available files from storage
class LoadContentState extends AssigncontentState {
  final List<UploadedFile> files;
  const LoadContentState(this.files);

  @override
  List<Object?> get props => [files];
}

/// Files assigned to a screen
class ScreenContentsLoaded extends AssigncontentState {
  final List<String> screenFiles;
  const ScreenContentsLoaded(this.screenFiles);

  @override
  List<Object?> get props => [screenFiles];
}

/// When assigning/reordering/deleting is in progress
class ScreenContentActionInProgress extends AssigncontentState {}

/// When action succeeded
class ScreenContentActionSuccess extends AssigncontentState {
  final List<String> updatedFiles;
  const ScreenContentActionSuccess(this.updatedFiles);

  @override
  List<Object?> get props => [updatedFiles];
}

/// When action failed
class ScreenContentActionFailure extends AssigncontentState {
  final String error;
  const ScreenContentActionFailure(this.error);

  @override
  List<Object?> get props => [error];
}
