import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:evide_dashboard/Domain/services/websocket_services.dart';

part 'assigncontent_event.dart';
part 'assigncontent_state.dart';

class AssigncontentBloc extends Bloc<AssigncontentEvent, AssigncontentState> {
  final WebSocketS3Service wsService;

  AssigncontentBloc(this.wsService) : super(AssigncontentInitial()) {
    /// Load all uploaded files
    on<LoadContent>((event, emit) async {
      emit(LoadingContentstate());
      try {
        print('📡 Fetching uploaded files with thumbnails to assign...');

        final files = await wsService.fetchUploadedFiles();
        final filesWithThumbnails = files.map((file) {
          return UploadedFile(
            filename: file.filename,
            url: file.url,
            thumbnail: file.thumbnail.isNotEmpty ? file.thumbnail : file.url,
            size: file.size,
          );
        }).toList();

        emit(LoadContentState(filesWithThumbnails));
        print('✅ Files fetched: ${filesWithThumbnails.length} items');
      } on HandshakeException {
        emit(
          const LoadingcontentError(
            message: "Secure connection failed (Handshake Error)",
          ),
        );
      } on SocketException {
        emit(
          const LoadingcontentError(
            message: "Network error while fetching files",
          ),
        );
      } catch (e) {
        emit(LoadingcontentError(message: e.toString()));
      }
    });

    /// Fetch contents of a specific screen
    on<FetchScreenContents>((event, emit) async {
      emit(ScreenContentActionInProgress());
      try {
        final files = await wsService.fetchScreenContents(
          pairingCode: event.pairingCode,
        );
        emit(ScreenContentsLoaded(files));
      } catch (e) {
        emit(ScreenContentActionFailure(e.toString()));
      }
    });

    /// Assign contents to screen
    on<AssignContentsToScreen>((event, emit) async {
      emit(ScreenContentActionInProgress());
      try {
        wsService.onMessage((msg) async {
          if (msg['type'] == 'content_assigned') {
            final files = List<String>.from(msg['files']);
            emit(ScreenContentActionSuccess(files));
          }
          await wsService.assignContentToScreen(
            pairingCode: event.pairingCode,
            files: event.files,
          );
        });
      } catch (e) {
        emit(ScreenContentActionFailure(e.toString()));
      }
    });

    /// Delete a content from screen
    on<DeleteScreenContent>((event, emit) async {
      emit(ScreenContentActionInProgress());
      try {
        wsService.onMessage((msg) {
          if (msg['type'] == 'content_deleted') {
            final files = List<String>.from(msg['files']);
            emit(ScreenContentActionSuccess(files));
          }
        });
        await wsService.deleteScreenContent(
          pairingCode: event.pairingCode,
          filename: event.filename,
        );
        print('deleted File...........${event.filename}');
        final files = await wsService.fetchScreenContents(
          pairingCode: event.pairingCode,
        );
        emit(ScreenContentsLoaded(files));
      } catch (e) {
        emit(ScreenContentActionFailure(e.toString()));
      }
    });

    /// Reorder screen contents
    on<ReorderScreenContents>((event, emit) async {
      emit(ScreenContentActionInProgress());
      try {
        await wsService.reorderScreenContents(
          pairingCode: event.pairingCode,
          files: event.files,
        );
      } catch (e) {
        emit(ScreenContentActionFailure(e.toString()));
      }
    });
    wsService.onMessage((msg) {
      if (msg['type'] == 'contents_reordered') {
        final files = List<String>.from(msg['files']);
        add(_ContentsReorderedEvent(files)); // <--- dispatch internal event
      }
    });
    on<_ContentsReorderedEvent>((event, emit) {
      emit(ScreenContentActionSuccess(event.files));
    });
  }
}

class _ContentsReorderedEvent extends AssigncontentEvent {
  final List<String> files;
  const _ContentsReorderedEvent(this.files);
}
