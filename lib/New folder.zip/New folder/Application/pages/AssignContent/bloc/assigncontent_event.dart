part of 'assigncontent_bloc.dart';

abstract class AssigncontentEvent extends Equatable {
  const AssigncontentEvent();

  @override
  List<Object?> get props => [];
}

/// Load all available contents from server
class LoadContent extends AssigncontentEvent {}

/// Fetch contents for a specific screen
class FetchScreenContents extends AssigncontentEvent {
  final String pairingCode;
  const FetchScreenContents(this.pairingCode);

  @override
  List<Object?> get props => [pairingCode];
}

/// Assign contents to a screen
class AssignContentsToScreen extends AssigncontentEvent {
  final String pairingCode;
  final List<String> files;
  const AssignContentsToScreen({
    required this.pairingCode,
    required this.files,
  });

  @override
  List<Object?> get props => [pairingCode, files];
}

/// Delete a content from a screen
class DeleteScreenContent extends AssigncontentEvent {
  final String pairingCode;
  final String filename;
  const DeleteScreenContent({
    required this.pairingCode,
    required this.filename,
  });

  @override
  List<Object?> get props => [pairingCode, filename];
}

/// Reorder screen contents
class ReorderScreenContents extends AssigncontentEvent {
  final String pairingCode;
  final List<String> files;
  const ReorderScreenContents({required this.pairingCode, required this.files});

  @override
  List<Object?> get props => [pairingCode, files];
}
