import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'login_event.dart';
import 'login_state.dart';

class LoginBloc extends Bloc<LoginEmailEvent, LoginState> {

  final FirebaseAuth _auth= FirebaseAuth.instance;
    final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  LoginBloc() : super(LoginEmailInitial()) {
    on<LoginEvent>((event, emit) async{

emit(EmailLoading());
try{
  final userCredential = await _auth.signInWithEmailAndPassword(email: event.email, password: event.password);

  final user = userCredential.user;
  if(user!= null){
    emit(EmailAuthenticated(user));
    await _firestore.collection('BusOperatorsLogin').doc('BusOperatorEmail').collection(event.email).doc('User credential').set({
            'email': event.email,
            'created at': DateTime.now(),
          });
  }else{
    emit(EmailUnAuthenticated());
  }
}catch(e){
  emit(EmailAuthenticatedError(message: 'Your Email and Password is Incorrect'));
  emit(EmailUnAuthenticated());
}
    });
on<SingupEvent>((event, emit) async {
      emit(EmailLoading());
      try {
        final userCredential = await _auth.createUserWithEmailAndPassword(
          email: event.email,
          password: event.password
        );

        final user = userCredential.user;
        if (user != null) {
          emit(EmailAuthenticated(user));
        } else {
          emit(EmailUnAuthenticated());
        }
      } catch (e) {
        emit(EmailAuthenticatedError(message: 'Failed to create account'));
        emit(EmailUnAuthenticated());
      }
    });
    on<CheckLoginStatus>((event, emit) async {
  final user = _auth.currentUser;
  if (user != null) {
    emit(EmailAuthenticated(user));
  } else {
    emit(EmailUnAuthenticated());
  }
});

    on<LogOutEvent>((event, emit) async {
      try {
        await _auth.signOut();
        emit(EmailUnAuthenticated());
      } catch (e) {
        emit(EmailAuthenticatedError(message: e.toString()));
      }
    });

  }
}
