import 'package:equatable/equatable.dart';
import 'package:firebase_auth/firebase_auth.dart';

sealed class LoginState extends Equatable {
  const LoginState();

  @override
  List<Object> get props => [];
}

class LoginEmailInitial extends LoginState {}

class EmailLoading extends LoginState {}

// ignore: must_be_immutable
class EmailAuthenticated extends LoginState {
  User? user;
  EmailAuthenticated(this.user);
}

class EmailUnAuthenticated extends LoginState {}

class EmailAuthenticatedError extends LoginState {
  final String message;

  const EmailAuthenticatedError({required this.message});
}
