import 'package:equatable/equatable.dart';

sealed class LoginEmailEvent extends Equatable {
  const LoginEmailEvent();

  @override
  List<Object> get props => [];
}
class CheckLoginStatus extends LoginEmailEvent{}
class LoginEvent extends LoginEmailEvent{
final String email;
final String password;

  const LoginEvent({required this.email, required this.password});

}
class SingupEvent extends LoginEmailEvent{
  final String email;
  final String password;

  const SingupEvent({required this.email, required this.password});
}
class LogOutEvent extends LoginEmailEvent{}