// services/content_service.dart
import 'dart:io';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:evide_dashboard/infrastructure/models/contents.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path/path.dart' as path;
import 'package:uuid/uuid.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:image/image.dart' as img;

class ContentService {
  static final ContentService _instance = ContentService._internal();
  factory ContentService() => _instance;
  ContentService._internal();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final Uuid _uuid = const Uuid();

  // Collection reference
  CollectionReference get _contentCollection => _firestore.collection('contents');

  // Get all contents
  Stream<List<ContentModel>> getContentsStream() {
    return _contentCollection
        .orderBy('uploadedAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => ContentModel.fromJson({
                  'id': doc.id,
                  ...doc.data() as Map<String, dynamic>,
                }))
            .toList());
  }

  // Get contents as Future
  Future<List<ContentModel>> getContents() async {
    try {
      QuerySnapshot snapshot = await _contentCollection
          .orderBy('uploadedAt', descending: true)
          .get();
      
      return snapshot.docs
          .map((doc) => ContentModel.fromJson({
                'id': doc.id,
                ...doc.data() as Map<String, dynamic>,
              }))
          .toList();
    } catch (e) {
      throw Exception('Failed to load contents: $e');
    }
  }

  // Upload content to S3 and save metadata to Firebase
  Future<ContentModel> uploadContent({
    required File file,
    required String fileName,
    required ContentTypes contentType,
    required Function(double) onProgress,
  }) async {
    try {
      // Generate unique content ID
      final contentId = _uuid.v4();
      final fileExtension = path.extension(fileName);
      final uniqueFileName = '${contentId}_$fileName';

      // Create storage reference
      final storageRef = _storage.ref().child('contents/$uniqueFileName');

      // Upload file with progress tracking
      final uploadTask = storageRef.putFile(file);
      
      uploadTask.snapshotEvents.listen((TaskSnapshot snapshot) {
        double progress = (snapshot.bytesTransferred / snapshot.totalBytes);
        onProgress(progress);
      });

      final taskSnapshot = await uploadTask;
      final downloadUrl = await taskSnapshot.ref.getDownloadURL();

      // Generate thumbnail
      String thumbnailUrl = '';
      if (contentType == ContentTypes.video) {
        thumbnailUrl = await _generateVideoThumbnail(file, contentId);
      } else if (contentType == ContentTypes.image) {
        thumbnailUrl = await _generateImageThumbnail(file, contentId);
      }

      // Get file size
      final fileSize = await file.length();

      // Create content model
      final content = ContentModel(
        id: contentId,
        name: fileName,
        url: downloadUrl,
        thumbnailUrl: thumbnailUrl,
        type: contentType,
        size: fileSize,
        uploadedAt: DateTime.now(),
        uploadedBy: 'current_user', // Replace with actual user ID
        metadata: {
          'originalFileName': fileName,
          'fileExtension': fileExtension,
          'mimeType': _getMimeType(fileExtension),
        },
      );

      // Save metadata to Firestore
      await _contentCollection.doc(contentId).set(content.toJson());

      return content;
    } catch (e) {
      throw Exception('Failed to upload content: $e');
    }
  }

  // Generate video thumbnail
  Future<String> _generateVideoThumbnail(File videoFile, String contentId) async {
    try {
      final thumbnailBytes = await VideoThumbnail.thumbnailData(
        video: videoFile.path,
        imageFormat: ImageFormat.JPEG,
        maxWidth: 300,
        maxHeight: 300,
        quality: 75,
      );

      if (thumbnailBytes != null) {
        final thumbnailRef = _storage.ref().child('thumbnails/${contentId}_thumb.jpg');
        final uploadTask = thumbnailRef.putData(thumbnailBytes);
        final snapshot = await uploadTask;
        return await snapshot.ref.getDownloadURL();
      }
      
      return '';
    } catch (e) {
      print('Failed to generate video thumbnail: $e');
      return '';
    }
  }

  // Generate image thumbnail
  Future<String> _generateImageThumbnail(File imageFile, String contentId) async {
    try {
      final imageBytes = await imageFile.readAsBytes();
      final image = img.decodeImage(imageBytes);
      
      if (image != null) {
        // Resize image to thumbnail size
        final thumbnail = img.copyResize(image, width: 300, height: 300);
        final thumbnailBytes = img.encodeJpg(thumbnail, quality: 75);

        final thumbnailRef = _storage.ref().child('thumbnails/${contentId}_thumb.jpg');
        final uploadTask = thumbnailRef.putData(Uint8List.fromList(thumbnailBytes));
        final snapshot = await uploadTask;
        return await snapshot.ref.getDownloadURL();
      }
      
      return '';
    } catch (e) {
      print('Failed to generate image thumbnail: $e');
      return '';
    }
  }

  // Delete content
  Future<void> deleteContent(String contentId) async {
    try {
      // Get content data first
      final doc = await _contentCollection.doc(contentId).get();
      if (doc.exists) {
        final content = ContentModel.fromJson({
          'id': doc.id,
          ...doc.data() as Map<String, dynamic>,
        });

        // Delete files from storage
        try {
          await _storage.refFromURL(content.url).delete();
          if (content.thumbnailUrl.isNotEmpty) {
            await _storage.refFromURL(content.thumbnailUrl).delete();
          }
        } catch (e) {
          print('Failed to delete storage files: $e');
        }

        // Delete from Firestore
        await _contentCollection.doc(contentId).delete();
      }
    } catch (e) {
      throw Exception('Failed to delete content: $e');
    }
  }

  // Delete multiple contents
  Future<void> deleteMultipleContents(List<String> contentIds) async {
    try {
      for (String contentId in contentIds) {
        await deleteContent(contentId);
      }
    } catch (e) {
      throw Exception('Failed to delete multiple contents: $e');
    }
  }

  // Get MIME type based on file extension
  String _getMimeType(String extension) {
    switch (extension.toLowerCase()) {
      case '.jpg':
      case '.jpeg':
        return 'image/jpeg';
      case '.png':
        return 'image/png';
      case '.gif':
        return 'image/gif';
      case '.webp':
        return 'image/webp';
      case '.mp4':
        return 'video/mp4';
      case '.mov':
        return 'video/quicktime';
      case '.avi':
        return 'video/x-msvideo';
      case '.mkv':
        return 'video/x-matroska';
      case '.webm':
        return 'video/webm';
      default:
        return 'application/octet-stream';
    }
  }

  // Get content by ID
  Future<ContentModel?> getContentById(String contentId) async {
    try {
      final doc = await _contentCollection.doc(contentId).get();
      if (doc.exists) {
        return ContentModel.fromJson({
          'id': doc.id,
          ...doc.data() as Map<String, dynamic>,
        });
      }
      return null;
    } catch (e) {
      throw Exception('Failed to get content: $e');
    }
  }

  // Search contents
  Future<List<ContentModel>> searchContents(String query) async {
    try {
      final contents = await getContents();
      return contents.where((content) =>
          content.name.toLowerCase().contains(query.toLowerCase()) ||
          content.type.toString().toLowerCase().contains(query.toLowerCase())
      ).toList();
    } catch (e) {
      throw Exception('Failed to search contents: $e');
    }
  }

  // Filter contents by type
  Future<List<ContentModel>> filterContentsByType(ContentType type) async {
    try {
      QuerySnapshot snapshot = await _contentCollection
          .where('type', isEqualTo: type.toString().split('.').last)
          .orderBy('uploadedAt', descending: true)
          .get();
      
      return snapshot.docs
          .map((doc) => ContentModel.fromJson({
                'id': doc.id,
                ...doc.data() as Map<String, dynamic>,
              }))
          .toList();
    } catch (e) {
      throw Exception('Failed to filter contents: $e');
    }
  }
}