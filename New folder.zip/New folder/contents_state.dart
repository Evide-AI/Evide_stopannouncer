// bloc/content_states.dart
import 'package:equatable/equatable.dart';
import 'package:evide_dashboard/infrastructure/models/contents.dart';


abstract class ContentState extends Equatable {
  const ContentState();

  @override
  List<Object?> get props => [];
}

class ContentInitial extends ContentState {
  const ContentInitial();
}

class ContentLoading extends ContentState {
  const ContentLoading();
}

class ContentLoaded extends ContentState {
  final List<ContentModel> contents;
  final List<ContentModel> filteredContents;
  final Set<String> selectedContentIds;
  final bool isUploading;
  final double uploadProgress;
  final String? uploadingFileName;
  final ContentTypes? filterType;
  final String? searchQuery;
  final bool isWebSocketConnected;

  const ContentLoaded({
    required this.contents,
    required this.filteredContents,
    this.selectedContentIds = const {},
    this.isUploading = false,
    this.uploadProgress = 0.0,
    this.uploadingFileName,
    this.filterType,
    this.searchQuery,
    this.isWebSocketConnected = false,
  });

  ContentLoaded copyWith({
    List<ContentModel>? contents,
    List<ContentModel>? filteredContents,
    Set<String>? selectedContentIds,
    bool? isUploading,
    double? uploadProgress,
    String? uploadingFileName,
    ContentTypes? filterType,
    String? searchQuery,
    bool? isWebSocketConnected,
    bool clearUploadingFileName = false,
    bool clearFilterType = false,
    bool clearSearchQuery = false,
  }) {
    return ContentLoaded(
      contents: contents ?? this.contents,
      filteredContents: filteredContents ?? this.filteredContents,
      selectedContentIds: selectedContentIds ?? this.selectedContentIds,
      isUploading: isUploading ?? this.isUploading,
      uploadProgress: uploadProgress ?? this.uploadProgress,
      uploadingFileName: clearUploadingFileName ? null : (uploadingFileName ?? this.uploadingFileName),
      filterType: clearFilterType ? null : (filterType ?? this.filterType),
      searchQuery: clearSearchQuery ? null : (searchQuery ?? this.searchQuery),
      isWebSocketConnected: isWebSocketConnected ?? this.isWebSocketConnected,
    );
  }

  @override
  List<Object?> get props => [
    contents,
    filteredContents,
    selectedContentIds,
    isUploading,
    uploadProgress,
    uploadingFileName,
    filterType,
    searchQuery,
    isWebSocketConnected,
  ];
}

class ContentError extends ContentState {
  final String message;
  final String? errorCode;

  const ContentError({
    required this.message,
    this.errorCode,
  });

  @override
  List<Object?> get props => [message, errorCode];
}

class ContentUploadSuccess extends ContentState {
  final ContentModel uploadedContent;

  const ContentUploadSuccess(this.uploadedContent);

  @override
  List<Object?> get props => [uploadedContent];
}

class ContentUploadProgress extends ContentState {
  final double progress;
  final String fileName;

  const ContentUploadProgress({
    required this.progress,
    required this.fileName,
  });

  @override
  List<Object?> get props => [progress, fileName];
}

class ContentDeleted extends ContentState {
  final String deletedContentId;

  const ContentDeleted(this.deletedContentId);

  @override
  List<Object?> get props => [deletedContentId];
}

class WebSocketConnected extends ContentState {
  const WebSocketConnected();
}

class WebSocketDisconnected extends ContentState {
  final String? reason;

  const WebSocketDisconnected({this.reason});

  @override
  List<Object?> get props => [reason];
}

class WebSocketError extends ContentState {
  final String error;

  const WebSocketError(this.error);

  @override
  List<Object?> get props => [error];
}