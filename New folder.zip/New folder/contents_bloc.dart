// bloc/content_bloc.dart
import 'dart:async';
import 'dart:io';
import 'package:evide_dashboard/Application/pages/Contents/bloc/contents_event.dart';
import 'package:evide_dashboard/Application/pages/Contents/bloc/contents_state.dart';
import 'package:evide_dashboard/Domain/services/content_service.dart';
import 'package:evide_dashboard/Domain/services/websocket_services.dart';
import 'package:evide_dashboard/infrastructure/models/contents.dart';
import 'package:flutter_bloc/flutter_bloc.dart';


class ContentBloc extends Bloc<ContentEvent, ContentState> {
  final ContentService _contentService = ContentService();
  final WebSocketService _webSocketService = WebSocketService();
  
  StreamSubscription? _contentStreamSubscription;
  StreamSubscription? _webSocketMessageSubscription;
  StreamSubscription? _webSocketConnectionSubscription;

  ContentBloc() : super(const ContentInitial()) {
    on<LoadContentEvent>(_onLoadContent);
    on<RefreshContentEvent>(_onRefreshContent);
    on<UploadContentEvent>(_onUploadContent);
    on<DeleteContentEvent>(_onDeleteContent);
    on<FilterContentEvent>(_onFilterContent);
    on<SelectContentEvent>(_onSelectContent);
    on<UnselectContentEvent>(_onUnselectContent);
    on<ClearSelectionEvent>(_onClearSelection);
    on<DeleteSelectedContentEvent>(_onDeleteSelectedContent);
    on<WebSocketConnectEvent>(_onWebSocketConnect);
    on<WebSocketDisconnectEvent>(_onWebSocketDisconnect);
    on<WebSocketMessageEvent>(_onWebSocketMessage);

    // Initialize WebSocket connection
    add(const WebSocketConnectEvent());
  }

  Future<void> _onLoadContent(LoadContentEvent event, Emitter<ContentState> emit) async {
    try {
      emit(const ContentLoading());
      
      // Set up real-time content stream
      _contentStreamSubscription?.cancel();
      _contentStreamSubscription = _contentService.getContentsStream().listen(
        (contents) {
          final currentState = state;
          if (currentState is ContentLoaded) {
            final filteredContents = _applyFilters(contents, 
              currentState.filterType, currentState.searchQuery);
            
            emit(currentState.copyWith(
              contents: contents,
              filteredContents: filteredContents,
            ));
          } else {
            emit(ContentLoaded(
              contents: contents,
              filteredContents: contents,
            ));
          }
        },
        onError: (error) {
          emit(ContentError(message: 'Failed to load contents: $error'));
        },
      );

    } catch (e) {
      emit(ContentError(message: 'Failed to initialize content stream: $e'));
    }
  }

  Future<void> _onRefreshContent(RefreshContentEvent event, Emitter<ContentState> emit) async {
    try {
      final contents = await _contentService.getContents();
      final currentState = state;
      
      if (currentState is ContentLoaded) {
        final filteredContents = _applyFilters(contents, 
          currentState.filterType, currentState.searchQuery);
        
        emit(currentState.copyWith(
          contents: contents,
          filteredContents: filteredContents,
        ));
      } else {
        emit(ContentLoaded(
          contents: contents,
          filteredContents: contents,
        ));
      }
    } catch (e) {
      emit(ContentError(message: 'Failed to refresh contents: $e'));
    }
  }

  Future<void> _onUploadContent(UploadContentEvent event, Emitter<ContentState> emit) async {
    try {
      final currentState = state;
      if (currentState is ContentLoaded) {
        emit(currentState.copyWith(
          isUploading: true,
          uploadProgress: 0.0,
          uploadingFileName: event.fileName,
        ));
      }

      final uploadedContent = await _contentService.uploadContent(
        file: event.file,
        fileName: event.fileName,
        contentType: event.contentTypes,
        onProgress: (progress) {
          final currentState = state;
          if (currentState is ContentLoaded) {
            emit(currentState.copyWith(uploadProgress: progress));
            
            // Notify via WebSocket
            _webSocketService.notifyUploadProgress(event.fileName, progress);
          }
        },
      );

      // Notify WebSocket about successful upload
      _webSocketService.notifyContentUploaded(
        uploadedContent.id,
        uploadedContent.name,
        uploadedContent.type.toString().split('.').last,
      );

      final currentState = state;
      if (currentState is ContentLoaded) {
        final updatedContents = [uploadedContent, ...currentState.contents];
        final filteredContents = _applyFilters(updatedContents, 
          currentState.filterType, currentState.searchQuery);
        
        emit(currentState.copyWith(
          contents: updatedContents,
          filteredContents: filteredContents,
          isUploading: false,
          uploadProgress: 0.0,
          clearUploadingFileName: true,
        ));
        
        // Emit success state briefly
        emit(ContentUploadSuccess(uploadedContent));
        
        // Return to normal loaded state
        await Future.delayed(const Duration(milliseconds: 500));
        emit(currentState.copyWith(
          contents: updatedContents,
          filteredContents: filteredContents,
          isUploading: false,
          uploadProgress: 0.0,
          clearUploadingFileName: true,
        ));
      }

    } catch (e) {
      final currentState = state;
      if (currentState is ContentLoaded) {
        emit(currentState.copyWith(
          isUploading: false,
          uploadProgress: 0.0,
          clearUploadingFileName: true,
        ));
      }
      emit(ContentError(message: 'Failed to upload content: $e'));
    }
  }

  Future<void> _onDeleteContent(DeleteContentEvent event, Emitter<ContentState> emit) async {
    try {
      await _contentService.deleteContent(event.contentId);
      
      // Notify WebSocket about deletion
      _webSocketService.notifyContentDeleted(event.contentId);

      final currentState = state;
      if (currentState is ContentLoaded) {
        final updatedContents = currentState.contents
            .where((content) => content.id != event.contentId)
            .toList();
        final filteredContents = _applyFilters(updatedContents, 
          currentState.filterType, currentState.searchQuery);
        
        // Remove from selection if selected
        final updatedSelection = Set<String>.from(currentState.selectedContentIds)
          ..remove(event.contentId);

        emit(currentState.copyWith(
          contents: updatedContents,
          filteredContents: filteredContents,
          selectedContentIds: updatedSelection,
        ));

        // Emit deletion success state briefly
        emit(ContentDeleted(event.contentId));
        
        // Return to normal loaded state
        await Future.delayed(const Duration(milliseconds: 300));
        emit(currentState.copyWith(
          contents: updatedContents,
          filteredContents: filteredContents,
          selectedContentIds: updatedSelection,
        ));
      }

    } catch (e) {
      emit(ContentError(message: 'Failed to delete content: $e'));
    }
  }

  Future<void> _onFilterContent(FilterContentEvent event, Emitter<ContentState> emit) async {
    final currentState = state;
    if (currentState is ContentLoaded) {
      final filteredContents = _applyFilters(currentState.contents, 
        event.contentType, event.searchQuery);
      
      emit(currentState.copyWith(
        filteredContents: filteredContents,
        filterType: event.contentType,
        searchQuery: event.searchQuery,
        clearFilterType: event.contentType == null,
        clearSearchQuery: event.searchQuery == null,
      ));
    }
  }

  Future<void> _onSelectContent(SelectContentEvent event, Emitter<ContentState> emit) async {
    final currentState = state;
    if (currentState is ContentLoaded) {
      final updatedSelection = Set<String>.from(currentState.selectedContentIds)
        ..add(event.contentId);
      
      emit(currentState.copyWith(selectedContentIds: updatedSelection));
    }
  }

  Future<void> _onUnselectContent(UnselectContentEvent event, Emitter<ContentState> emit) async {
    final currentState = state;
    if (currentState is ContentLoaded) {
      final updatedSelection = Set<String>.from(currentState.selectedContentIds)
        ..remove(event.contentId);
      
      emit(currentState.copyWith(selectedContentIds: updatedSelection));
    }
  }

  Future<void> _onClearSelection(ClearSelectionEvent event, Emitter<ContentState> emit) async {
    final currentState = state;
    if (currentState is ContentLoaded) {
      emit(currentState.copyWith(selectedContentIds: const <String>{}));
    }
  }

  Future<void> _onDeleteSelectedContent(DeleteSelectedContentEvent event, Emitter<ContentState> emit) async {
    final currentState = state;
    if (currentState is ContentLoaded && currentState.selectedContentIds.isNotEmpty) {
      try {
        // Delete all selected contents
        await _contentService.deleteMultipleContents(
          currentState.selectedContentIds.toList()
        );

        // Notify WebSocket about deletions
        for (String contentId in currentState.selectedContentIds) {
          _webSocketService.notifyContentDeleted(contentId);
        }

        final updatedContents = currentState.contents
            .where((content) => !currentState.selectedContentIds.contains(content.id))
            .toList();
        final filteredContents = _applyFilters(updatedContents, 
          currentState.filterType, currentState.searchQuery);

        emit(currentState.copyWith(
          contents: updatedContents,
          filteredContents: filteredContents,
          selectedContentIds: const <String>{},
        ));

      } catch (e) {
        emit(ContentError(message: 'Failed to delete selected contents: $e'));
      }
    }
  }

  Future<void> _onWebSocketConnect(WebSocketConnectEvent event, Emitter<ContentState> emit) async {
    try {
      await _webSocketService.connect();
      
      // Listen to WebSocket messages
      _webSocketMessageSubscription?.cancel();
      _webSocketMessageSubscription = _webSocketService.messageStream.listen(
        (message) => add(WebSocketMessageEvent(message)),
      );

      // Listen to WebSocket connection status
      _webSocketConnectionSubscription?.cancel();
      _webSocketConnectionSubscription = _webSocketService.connectionStream.listen(
        (isConnected) {
          final currentState = state;
          if (currentState is ContentLoaded) {
            emit(currentState.copyWith(isWebSocketConnected: isConnected));
          }
          
          if (isConnected) {
            emit(const WebSocketConnected());
          } else {
            emit(const WebSocketDisconnected());
          }
        },
      );

    } catch (e) {
      emit(WebSocketError('Failed to connect to WebSocket: $e'));
    }
  }

  Future<void> _onWebSocketDisconnect(WebSocketDisconnectEvent event, Emitter<ContentState> emit) async {
    await _webSocketService.disconnect();
    
    final currentState = state;
    if (currentState is ContentLoaded) {
      emit(currentState.copyWith(isWebSocketConnected: false));
    }
    
    emit(const WebSocketDisconnected(reason: 'Manual disconnect'));
  }

  Future<void> _onWebSocketMessage(WebSocketMessageEvent event, Emitter<ContentState> emit) async {
    try {
      final message = event.message;
      final messageType = message['type'] as String?;

      switch (messageType) {
        case 'content_uploaded':
          // Handle real-time content upload notification
          add(const RefreshContentEvent());
          break;
          
        case 'content_deleted':
          // Handle real-time content deletion notification
          add(const RefreshContentEvent());
          break;
          
        case 'content_updated':
          // Handle real-time content update notification
          add(const RefreshContentEvent());
          break;
          
        case 'upload_progress':
          // Handle real-time upload progress from other clients
          final fileName = message['fileName'] as String?;
          final progress = (message['progress'] as num?)?.toDouble();
          
          if (fileName != null && progress != null) {
            emit(ContentUploadProgress(progress: progress, fileName: fileName));
          }
          break;
          
        default:
          print('Unknown WebSocket message type: $messageType');
      }

    } catch (e) {
      print('Error handling WebSocket message: $e');
    }
  }

  List<ContentModel> _applyFilters(
    List<ContentModel> contents, 
    ContentType? filterType, 
    String? searchQuery
  ) {
    var filtered = contents;

    // Apply type filter
    if (filterType != null) {
      filtered = filtered.where((content) => content.type == filterType).toList();
    }

    // Apply search filter
    if (searchQuery != null && searchQuery.isNotEmpty) {
      filtered = filtered.where((content) =>
          content.name.toLowerCase().contains(searchQuery.toLowerCase()) ||
          content.type.toString().toLowerCase().contains(searchQuery.toLowerCase())
      ).toList();
    }

    return filtered;
  }

  @override
  Future<void> close() {
    _contentStreamSubscription?.cancel();
    _webSocketMessageSubscription?.cancel();
    _webSocketConnectionSubscription?.cancel();
    _webSocketService.dispose();
    return super.close();
  }
}