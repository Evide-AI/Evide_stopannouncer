// pages/content_page.dart
import 'dart:io' as io;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:evide_dashboard/Application/pages/Contents/bloc/contents_bloc.dart';
import 'package:evide_dashboard/Application/pages/Contents/bloc/contents_event.dart';
import 'package:evide_dashboard/Application/pages/Contents/bloc/contents_state.dart';
import 'package:evide_dashboard/Application/widgets/content_filter_bar.dart';
import 'package:evide_dashboard/Application/widgets/content_grid_item.dart';
import 'package:evide_dashboard/Application/widgets/content_list_list.dart';
import 'package:evide_dashboard/Application/widgets/content_upload_dialog.dart';
import 'package:evide_dashboard/infrastructure/models/contents.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:video_player/video_player.dart';

class ContentPage extends StatefulWidget {
  const ContentPage({super.key});

  @override
  State<ContentPage> createState() => _ContentPageState();
}

class _ContentPageState extends State<ContentPage> with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  
  bool _isGridView = true;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOutCubic,
    ));

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOutBack,
    ));
    
    _animationController.forward();
    
    // Load contents on page init
    context.read<ContentBloc>().add(const LoadContentEvent());
  }

  @override
  void dispose() {
    _animationController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        margin: const EdgeInsets.all(20),
        child: Column(
          children: [
            SlideTransition(
              position: _slideAnimation,
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: _buildHeader(),
              ),
            ),
            const SizedBox(height: 20),
            FadeTransition(
              opacity: _fadeAnimation,
              child: _buildFilterBar(),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: _buildContentArea(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFf093fb), Color(0xFFf5576c)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFf093fb).withOpacity(0.3),
            spreadRadius: 0,
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Icon(
                      Icons.perm_media_rounded,
                      size: 40,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Content Library',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Manage your media content and playlists',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white.withOpacity(0.9),
                      letterSpacing: 0.3,
                    ),
                  ),
                ],
              ),
              Column(
                children: [
                  _buildUploadButton(),
                  const SizedBox(height: 12),
                  _buildViewToggle(),
                ],
              ),
            ],
          ),
          const SizedBox(height: 20),
          BlocBuilder<ContentBloc, ContentState>(
            builder: (context, state) {
              if (state is ContentLoaded) {
                return _buildStatsRow(state);
              }
              return const SizedBox.shrink();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildStatsRow(ContentLoaded state) {
    final totalCount = state.contents.length;
    final videoCount = state.contents.where((c) => c.isVideo).length;
    final imageCount = state.contents.where((c) => c.isImage).length;
    final selectedCount = state.selectedContentIds.length;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatItem('Total', totalCount.toString(), Icons.folder_rounded),
          _buildStatItem('Videos', videoCount.toString(), Icons.video_library_rounded),
          _buildStatItem('Images', imageCount.toString(), Icons.image_rounded),
          if (selectedCount > 0)
            _buildStatItem('Selected', selectedCount.toString(), Icons.check_circle_rounded),
          if (state.isWebSocketConnected)
            _buildStatItem('Live', '●', Icons.wifi_rounded, isLive: true),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon, {bool isLive = false}) {
    return Column(
      children: [
        Icon(
          icon,
          color: isLive ? Colors.greenAccent : Colors.white.withOpacity(0.8),
          size: 20,
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: isLive ? Colors.greenAccent : Colors.white,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.white.withOpacity(0.7),
          ),
        ),
      ],
    );
  }

  Widget _buildUploadButton() {
    return BlocBuilder<ContentBloc, ContentState>(
      builder: (context, state) {
        final isUploading = state is ContentLoaded && state.isUploading;
        
        return ElevatedButton.icon(
          onPressed: isUploading ? null : _showUploadDialog,
          icon: isUploading 
            ? SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              )
            : const Icon(Icons.upload_rounded, color: Colors.white),
          label: Text(
            isUploading ? 'Uploading...' : 'Upload',
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
            ),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.white.withOpacity(0.2),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            elevation: 0,
          ),
        );
      },
    );
  }

  Widget _buildViewToggle() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            onPressed: () => setState(() => _isGridView = true),
            icon: Icon(
              Icons.grid_view_rounded,
              color: _isGridView ? Colors.white : Colors.white.withOpacity(0.5),
            ),
            tooltip: 'Grid View',
          ),
          IconButton(
            onPressed: () => setState(() => _isGridView = false),
            icon: Icon(
              Icons.list_rounded,
              color: !_isGridView ? Colors.white : Colors.white.withOpacity(0.5),
            ),
            tooltip: 'List View',
          ),
        ],
      ),
    );
  }

  Widget _buildFilterBar() {
    return ContentFilterBar(
      searchController: _searchController,
      onSearch: (query) {
        context.read<ContentBloc>().add(FilterContentEvent(searchQuery: query));
      },
      onFilterByType: (type) {
        context.read<ContentBloc>().add(FilterContentEvent(contentType: type));
      },
      onClearFilters: () {
        _searchController.clear();
        context.read<ContentBloc>().add(const FilterContentEvent());
      },
    );
  }

  Widget _buildContentArea() {
    return BlocConsumer<ContentBloc, ContentState>(
      listener: (context, state) {
        if (state is ContentError) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.message),
              backgroundColor: Colors.red,
            ),
          );
        } else if (state is ContentUploadSuccess) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Successfully uploaded ${state.uploadedContent.name}'),
              backgroundColor: Colors.green,
            ),
          );
        } else if (state is ContentDeleted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Content deleted successfully'),
              backgroundColor: Colors.orange,
            ),
          );
        }
      },
      builder: (context, state) {
        if (state is ContentLoading) {
          return _buildLoadingState();
        } else if (state is ContentLoaded) {
          return _buildLoadedState(state);
        } else if (state is ContentError) {
          return _buildErrorState(state);
        } else {
          return _buildInitialState();
        }
      },
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  spreadRadius: 0,
                  blurRadius: 20,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF667eea)),
              ),
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Loading your content library...',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Color(0xFF64748B),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadedState(ContentLoaded state) {
    if (state.filteredContents.isEmpty) {
      return _buildEmptyState();
    }

    return Column(
      children: [
        if (state.selectedContentIds.isNotEmpty)
          _buildSelectionActions(state),
        Expanded(
          child: _isGridView 
            ? _buildGridView(state.filteredContents, state.selectedContentIds)
            : _buildListView(state.filteredContents, state.selectedContentIds),
        ),
        if (state.isUploading)
          _buildUploadProgress(state),
      ],
    );
  }

  Widget _buildSelectionActions(ContentLoaded state) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.blue.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Text(
            '${state.selectedContentIds.length} items selected',
            style: const TextStyle(
              fontWeight: FontWeight.w600,
              color: Colors.blue,
            ),
          ),
          const Spacer(),
          TextButton.icon(
            onPressed: () {
              context.read<ContentBloc>().add(const ClearSelectionEvent());
            },
            icon: const Icon(Icons.clear, size: 18),
            label: const Text('Clear'),
          ),
          const SizedBox(width: 8),
          ElevatedButton.icon(
            onPressed: () => _confirmDeleteSelected(context),
            icon: const Icon(Icons.delete, size: 18),
            label: const Text('Delete Selected'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGridView(List<ContentModel> contents, Set<String> selectedIds) {
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 0.8,
      ),
      itemCount: contents.length,
      itemBuilder: (context, index) {
        final content = contents[index];
        return ContentGridItem(
          content: content,
          isSelected: selectedIds.contains(content.id),
          onTap: () => _handleContentTap(content),
          onLongPress: () => _handleContentLongPress(content),
          onDelete: () => _confirmDelete(context, content),
        );
      },
    );
  }

  Widget _buildListView(List<ContentModel> contents, Set<String> selectedIds) {
    return ListView.builder(
      itemCount: contents.length,
      itemBuilder: (context, index) {
        final content = contents[index];
        return ContentListItem(
          content: content,
          isSelected: selectedIds.contains(content.id),
          onTap: () => _handleContentTap(content),
          onLongPress: () => _handleContentLongPress(content),
          onDelete: () => _confirmDelete(context, content),
        );
      },
    );
  }

  Widget _buildUploadProgress(ContentLoaded state) {
    return Container(
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Row(
            children: [
              const Icon(Icons.upload_rounded, color: Colors.blue),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Uploading: ${state.uploadingFileName ?? "Unknown file"}',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
              Text(
                '${(state.uploadProgress * 100).toStringAsFixed(1)}%',
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  color: Colors.blue,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          LinearProgressIndicator(
            value: state.uploadProgress,
            backgroundColor: Colors.grey.withOpacity(0.3),
            valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(48),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              spreadRadius: 0,
              blurRadius: 30,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: const Color(0xFF667eea).withOpacity(0.1),
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Icon(
                Icons.folder_open_rounded,
                size: 48,
                color: Color(0xFF667eea),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'No content found',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: Color(0xFF64748B),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Upload your first video or image to get started',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF64748B).withOpacity(0.7),
                height: 1.5,
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _showUploadDialog,
              icon: const Icon(Icons.upload_rounded),
              label: const Text('Upload Content'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF667eea),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState(ContentError state) {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(48),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              spreadRadius: 0,
              blurRadius: 30,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.1),
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Icon(
                Icons.error_outline_rounded,
                size: 48,
                color: Colors.red,
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Something went wrong',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: Color(0xFF64748B),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              state.message,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF64748B).withOpacity(0.7),
                height: 1.5,
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                context.read<ContentBloc>().add(const LoadContentEvent());
              },
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Try Again'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF667eea),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInitialState() {
    return Center(
      child: ElevatedButton.icon(
        onPressed: () {
          context.read<ContentBloc>().add(const LoadContentEvent());
        },
        icon: const Icon(Icons.refresh_rounded),
        label: const Text('Load Content'),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF667eea),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  void _handleContentTap(ContentModel content) {
    final bloc = context.read<ContentBloc>();
    final state = bloc.state;
    
    if (state is ContentLoaded && state.selectedContentIds.isNotEmpty) {
      // If in selection mode, toggle selection
      if (state.selectedContentIds.contains(content.id)) {
        bloc.add(UnselectContentEvent(content.id));
      } else {
        bloc.add(SelectContentEvent(content.id));
      }
    } else {
      // Preview content
      _previewContent(content);
    }
  }

  void _handleContentLongPress(ContentModel content) {
    final bloc = context.read<ContentBloc>();
    bloc.add(SelectContentEvent(content.id));
  }

  void _previewContent(ContentModel content) {
    showDialog(
      context: context,
      builder: (context) => ContentPreviewDialog(content: content),
    );
  }

  void _showUploadDialog() {
    showDialog(
      context: context,
      builder: (context) => BlocProvider.value(
        value: context.read<ContentBloc>(),
        child: const ContentUploadDialog(),
      ),
    );
  }

  void _confirmDelete(BuildContext context, ContentModel content) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Content'),
        content: Text('Are you sure you want to delete "${content.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              context.read<ContentBloc>().add(DeleteContentEvent(content.id));
              Navigator.of(context).pop();
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _confirmDeleteSelected(BuildContext context) {
    final state = context.read<ContentBloc>().state;
    if (state is! ContentLoaded || state.selectedContentIds.isEmpty) return;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Selected Content'),
        content: Text(
          'Are you sure you want to delete ${state.selectedContentIds.length} selected items?'
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              context.read<ContentBloc>().add(const DeleteSelectedContentEvent());
              Navigator.of(context).pop();
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete All'),
          ),
        ],
      ),
    );
  }
}

// Content Preview Dialog
class ContentPreviewDialog extends StatefulWidget {
  final ContentModel content;

  const ContentPreviewDialog({super.key, required this.content});

  @override
  State<ContentPreviewDialog> createState() => _ContentPreviewDialogState();
}

class _ContentPreviewDialogState extends State<ContentPreviewDialog> {
  VideoPlayerController? _videoController;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    if (widget.content.isVideo) {
      _initializeVideo();
    }
  }

  void _initializeVideo() async {
    _videoController = VideoPlayerController.network(widget.content.url);
    try {
      await _videoController!.initialize();
      setState(() {
        _isVideoInitialized = true;
      });
    } catch (e) {
      print('Failed to initialize video: $e');
    }
  }

  @override
  void dispose() {
    _videoController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        width: MediaQuery.of(context).size.width * 0.8,
        height: MediaQuery.of(context).size.height * 0.8,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFF667eea),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    widget.content.isVideo ? Icons.play_circle : Icons.image,
                    color: Colors.white,
                    size: 24,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      widget.content.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close, color: Colors.white),
                  ),
                ],
              ),
            ),
            // Content
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: widget.content.isVideo
                    ? _buildVideoPreview()
                    : _buildImagePreview(),
              ),
            ),
            // Footer with details
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.grey.withOpacity(0.1),
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(20),
                  bottomRight: Radius.circular(20),
                ),
              ),
              child: _buildContentDetails(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVideoPreview() {
    if (_videoController == null || !_isVideoInitialized) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    return Center(
      child: AspectRatio(
        aspectRatio: _videoController!.value.aspectRatio,
        child: Stack(
          children: [
            VideoPlayer(_videoController!),
            Positioned.fill(
              child: Center(
                child: IconButton(
                  onPressed: () {
                    setState(() {
                      if (_videoController!.value.isPlaying) {
                        _videoController!.pause();
                      } else {
                        _videoController!.play();
                      }
                    });
                  },
                  icon: Icon(
                    _videoController!.value.isPlaying
                        ? Icons.pause_circle_filled
                        : Icons.play_circle_filled,
                    size: 64,
                    color: Colors.white.withOpacity(0.8),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImagePreview() {
    return Center(
      child: CachedNetworkImage(
        imageUrl: widget.content.url,
        fit: BoxFit.contain,
        placeholder: (context, url) => const CircularProgressIndicator(),
        errorWidget: (context, url, error) => const Icon(
          Icons.error,
          size: 64,
          color: Colors.red,
        ),
      ),
    );
  }

  Widget _buildContentDetails() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            _buildDetailItem('Size', widget.content.formattedSize),
            const SizedBox(width: 32),
            _buildDetailItem('Type', widget.content.fileExtension.toUpperCase()),
            const SizedBox(width: 32),
            _buildDetailItem('Uploaded', _formatDate(widget.content.uploadedAt)),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: ElevatedButton.icon(
                onPressed: () => _downloadContent(),
                icon: const Icon(Icons.download),
                label: const Text('Download'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ElevatedButton.icon(
                onPressed: () => _shareContent(),
                icon: const Icon(Icons.share),
                label: const Text('Share'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildDetailItem(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  void _downloadContent() {
    // Implement download functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Download feature coming soon!')),
    );
  }

  void _shareContent() {
    // Implement share functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Share feature coming soon!')),
    );
  }
}