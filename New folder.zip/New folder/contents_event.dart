// bloc/content_events.dart
import 'dart:io';
import 'package:equatable/equatable.dart';

abstract class ContentEvent extends Equatable {
  const ContentEvent();

  @override
  List<Object?> get props => [];
}

class LoadContentEvent extends ContentEvent {
  const LoadContentEvent();
}

class RefreshContentEvent extends ContentEvent {
  const RefreshContentEvent();
}

class UploadContentEvent extends ContentEvent {
  final File file;
  final String fileName;
  final ContentType contentType;

  const UploadContentEvent({
    required this.file,
    required this.fileName,
    required this.contentType,
  });

  @override
  List<Object?> get props => [file, fileName, contentType];
}

class DeleteContentEvent extends ContentEvent {
  final String contentId;

  const DeleteContentEvent(this.contentId);

  @override
  List<Object?> get props => [contentId];
}

class FilterContentEvent extends ContentEvent {
  final ContentType? contentType;
  final String? searchQuery;

  const FilterContentEvent({
    this.contentType,
    this.searchQuery,
  });

  @override
  List<Object?> get props => [contentType, searchQuery];
}

class SelectContentEvent extends ContentEvent {
  final String contentId;

  const SelectContentEvent(this.contentId);

  @override
  List<Object?> get props => [contentId];
}

class UnselectContentEvent extends ContentEvent {
  final String contentId;

  const UnselectContentEvent(this.contentId);

  @override
  List<Object?> get props => [contentId];
}

class ClearSelectionEvent extends ContentEvent {
  const ClearSelectionEvent();
}

class DeleteSelectedContentEvent extends ContentEvent {
  const DeleteSelectedContentEvent();
}

class WebSocketConnectEvent extends ContentEvent {
  const WebSocketConnectEvent();
}

class WebSocketDisconnectEvent extends ContentEvent {
  const WebSocketDisconnectEvent();
}

class WebSocketMessageEvent extends ContentEvent {
  final Map<String, dynamic> message;

  const WebSocketMessageEvent(this.message);

  @override
  List<Object?> get props => [message];
}