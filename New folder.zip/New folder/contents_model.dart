// models/content_model.dart
import 'package:cloud_firestore/cloud_firestore.dart';

enum ContentTypes { video, image }

class ContentModel {
  final String id;
  final String name;
  final String url;
  final String thumbnailUrl;
  final ContentTypes type;
  final int size;
  final DateTime uploadedAt;
  final String uploadedBy;
  final Map<String, dynamic>? metadata;

  ContentModel({
    required this.id,
    required this.name,
    required this.url,
    required this.thumbnailUrl,
    required this.type,
    required this.size,
    required this.uploadedAt,
    required this.uploadedBy,
    this.metadata,
  });

  factory ContentModel.fromJson(Map<String, dynamic> json) {
    return ContentModel(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      url: json['url'] ?? '',
      thumbnailUrl: json['thumbnailUrl'] ?? '',
      type: ContentTypes.values.firstWhere(
        (e) => e.toString() == 'ContentType.${json['type']}',
        orElse: () => ContentTypes.image,
      ),
      size: json['size'] ?? 0,
      uploadedAt: (json['uploadedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      uploadedBy: json['uploadedBy'] ?? '',
      metadata: json['metadata'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'url': url,
      'thumbnailUrl': thumbnailUrl,
      'type': type.toString().split('.').last,
      'size': size,
      'uploadedAt': Timestamp.fromDate(uploadedAt),
      'uploadedBy': uploadedBy,
      'metadata': metadata,
    };
  }

  ContentModel copyWith({
    String? id,
    String? name,
    String? url,
    String? thumbnailUrl,
    ContentTypes? type,
    int? size,
    DateTime? uploadedAt,
    String? uploadedBy,
    Map<String, dynamic>? metadata,
  }) {
    return ContentModel(
      id: id ?? this.id,
      name: name ?? this.name,
      url: url ?? this.url,
      thumbnailUrl: thumbnailUrl ?? this.thumbnailUrl,
      type: type ?? this.type,
      size: size ?? this.size,
      uploadedAt: uploadedAt ?? this.uploadedAt,
      uploadedBy: uploadedBy ?? this.uploadedBy,
      metadata: metadata ?? this.metadata,
    );
  }

  String get formattedSize {
    if (size < 1024) return '${size}B';
    if (size < 1024 * 1024) return '${(size / 1024).toStringAsFixed(1)}KB';
    if (size < 1024 * 1024 * 1024) return '${(size / (1024 * 1024)).toStringAsFixed(1)}MB';
    return '${(size / (1024 * 1024 * 1024)).toStringAsFixed(1)}GB';
  }

  String get fileExtension {
    return name.split('.').last.toLowerCase();
  }

  bool get isVideo => type == ContentTypes.video;
  bool get isImage => type == ContentTypes.image;
}