#import <Flutter/Flutter.h>

@interface UsbSerialPlugin : NSObject<FlutterPlugin>
@end
